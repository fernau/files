<!--

    Copyright (c) 2019-present Sonatype, Inc. All rights reserved.
    Includes the third-party code listed at http://links.sonatype.com/products/nexus/attributions.
    "Sonatype" is a trademark of Sonatype, Inc.

-->
# Firewall for JFrog Artifactory

"JFrog Artifactory" is a trademark of JFrog Ltd. and is used according to the brand guidelines provided here: https://jfrog.com/brand-guidelines/

The word "Artifactory" is used as a shorthand of "JFrog Artifactory" in the source code.

A plugin for JFrog Artifactory to enable Nexus Firewall. 

For details on plugin architecture and instructions to set up the plugin, please look at [overview](https://github.com/sonatype/firewall-for-jfrog-artifactory/blob/main/docs/overview.md)

## Contributing Guidelines
We welcome contributions to our code. See https://docs.sonatype.com/display/INT/Contributing+Guidelines for more information. 
