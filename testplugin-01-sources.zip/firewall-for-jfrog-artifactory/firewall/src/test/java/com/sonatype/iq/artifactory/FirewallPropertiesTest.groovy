/*
 * Copyright (c) 2019-present Sonatype, Inc. All rights reserved.
 * Includes the third-party code listed at http://links.sonatype.com/products/nexus/attributions.
 * "Sonatype" is a trademark of Sonatype, Inc.
 */
package com.sonatype.iq.artifactory

import com.sonatype.iq.artifactory.FirewallProperties.MODE

import org.slf4j.Logger
import spock.lang.Specification
import spock.lang.Unroll

class FirewallPropertiesTest
    extends Specification
{
  Logger logger

  def 'setup'() {
    logger = Mock()
  }

  def 'test golden config'() {
    given:
      Properties properties = new Properties()
      properties.putAll([
          'foo'                          : 'bar',
          'firewall.repo.main-java-libs' : 'quarantine',
          'firewall.repo.other-java-libs': 'audit'
      ])

    when:
      def result = FirewallProperties.load(properties, logger).getRepositories()

    then:
      result == ['main-java-libs': MODE.quarantine, 'other-java-libs': MODE.audit]
  }

  def "test non-repo config is ignored"() {
    given:
      Properties properties = new Properties()
      properties.putAll([
          'foo'                          : 'bar',
          'firewall.repo.main-java-libs' : 'quarantine',
          'firewall.repo.other-java-libs': 'audit'
      ])

    when:
      def result = FirewallProperties.load(properties, logger).getRepositories()

    then:
      result == ['main-java-libs': MODE.quarantine, 'other-java-libs': MODE.audit]
  }

  def "ensure bad mode throws error"() {
    given:
      Properties properties = new Properties()
      properties.putAll([
          'firewall.repo.foo': 'quarantine',
          'firewall.repo.bar': 'bad'
      ])

    when:
      FirewallProperties firewallProperties = FirewallProperties.load(properties, logger)
      def result = firewallProperties.getRepositories()

    then:
      1 * logger.error("Unknown option 'bad' for repository 'firewall.repo.bar'. Allowed values are: quarantine, " +
          "audit, policyCompliantComponentSelection, proprietary, disabled")
  }

  def 'get mode of repository'() {
    given:
      Properties properties = new Properties()
      properties.putAll([
          'firewall.repo.main-java-libs' : 'quarantine',
          'firewall.repo.other-java-libs': 'audit',
          'firewall.repo.test-repo-pccs': 'policyCompliantComponentSelection'
      ])

    when:
      def firewallProperties = FirewallProperties.load(properties, logger)

    then:
      firewallProperties.getRepositoryMode('main-java-libs') == MODE.quarantine
      firewallProperties.getRepositoryMode('other-java-libs') == MODE.audit
      firewallProperties.getRepositoryMode('test-repo-pccs') == MODE.policyCompliantComponentSelection
  }

  def 'get iq config'() {
    given:
      Properties properties = new Properties()
      properties.putAll([
          'firewall.iq.url'                      : 'http://localhost:8080',
          'firewall.iq.username'                 : 'admin',
          'firewall.iq.password'                 : 'admin123'
      ])

    when:
      def firewallProperties = FirewallProperties.load(properties, logger)

    then:
      firewallProperties.iqUrl == 'http://localhost:8080'
      firewallProperties.iqUsername == 'admin'
      firewallProperties.iqPassword == 'admin123'
  }

  def 'get connection timeouts'() {
    given:
      Properties properties = new Properties()
      properties.putAll([
          'firewall.iq.connect.timeout.in.millis' : '20000',
          'firewall.iq.socket.timeout.in.millis': '30000'
      ])

    when:
      def firewallProperties = FirewallProperties.load(properties, logger)

    then:
      firewallProperties.iqConnectTimeoutInMillis == 20000
      firewallProperties.iqSocketTimeoutInMillis == 30000
  }

  def 'get quarantine update millis configured'() {
    given:
      Properties properties = new Properties()
      properties.putAll([
          'firewall.unquarantine.update.in.millis' : '100000'
      ])

    when:
      def firewallProperties = FirewallProperties.load(properties, logger)

    then:
      firewallProperties.unquarantineUpdateInMillis == 100000
  }

  def 'get verify wait millis configured'() {
    given:
      Properties properties = new Properties()
      properties.putAll([
          'firewall.verify.wait.in.millis' : '12000'
      ])

    when:
      def firewallProperties = FirewallProperties.load(properties, logger)

    then:
      firewallProperties.verifyInitWaitInMillis == 12000
  }

  def 'get iq public url'() {
    given:
      def testUrl = '/test/url'
      Properties properties = new Properties()
      properties.putAll([
          'firewall.iq.public.url' : testUrl
      ])

    when:
      def firewallProperties = FirewallProperties.load(properties, logger)

    then:
      firewallProperties.iqPublicUrl == testUrl
  }

  def 'get proxy config'() {
    given:
      Properties properties = new Properties()
      properties.putAll([
          'firewall.iq.proxy.hostname'        : 'localhost',
          'firewall.iq.proxy.port'            : '1234',
          'firewall.iq.proxy.username'        : 'foo',
          'firewall.iq.proxy.password'        : 'bar',
          'firewall.iq.proxy.ntlm.domain'     : 'dom',
          'firewall.iq.proxy.ntlm.workstation': 'wk'
      ])

    when:
      def firewallProperties = FirewallProperties.load(properties, logger)

    then:
      firewallProperties.proxyHostname == 'localhost'
      firewallProperties.proxyPort == 1234
      firewallProperties.proxyUsername == 'foo'
      firewallProperties.proxyPassword == 'bar'
      firewallProperties.proxyNtlmDomain == 'dom'
      firewallProperties.proxyNtlmWorkstation == 'wk'
  }

  @Unroll
  def 'test valid repository manager id - #value'() {
    given:
      Properties properties = new Properties()
      properties.putAll(['firewall.repository.manager.id': value])

    when:
      FirewallProperties.load(properties, logger)

    then:
      noExceptionThrown()

    where:
      value << ['foo', 'foo-bar', 'foo_bar', '_foo', 'foo_', '-foo', 'foo-', 'Foo', 'FooBar']
  }

  @Unroll
  def 'test invalid repository manager id - #value'() {
    given:
      Properties properties = new Properties()
      properties.putAll(['firewall.repository.manager.id': value])

    when:
      FirewallProperties.load(properties, logger)

    then:
      thrown(InvalidPropertiesException)

    where:
      value << ['baz!', 'baz~', 'foo bar', 'f@o', 'foo^bar']
  }

  @Unroll
  def 'test deprecated config property logs warning - property: #propertyName'() {
    given:
      Properties properties = new Properties()
      properties.put(propertyName, 'foo')

    when:
      FirewallProperties.load(properties, logger)

    then:
      1 * logger.warn("The ${propertyName} property is deprecated and ignored.")

    where:
      propertyName << FirewallProperties.FIREWALL_CACHE_DEPRECATED_PROPERTIES
  }
}
