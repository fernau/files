/*
 * Copyright (c) 2019-present Sonatype, Inc. All rights reserved.
 * Includes the third-party code listed at http://links.sonatype.com/products/nexus/attributions.
 * "Sonatype" is a trademark of Sonatype, Inc.
 */
package com.sonatype.iq.artifactory

import com.sonatype.iq.artifactory.restclient.RestClientConfiguration
import com.sonatype.iq.artifactory.restclient.RestClientFactory

import org.artifactory.repo.Repositories
import org.artifactory.repo.RepositoryConfiguration
import org.slf4j.Logger
import spock.lang.Specification
import spock.lang.Unroll

import static com.sonatype.iq.artifactory.FirewallProperties.MODE.audit
import static com.sonatype.iq.artifactory.FirewallProperties.MODE.disabled
import static com.sonatype.iq.artifactory.FirewallProperties.MODE.policyCompliantComponentSelection
import static com.sonatype.iq.artifactory.FirewallProperties.MODE.proprietary
import static com.sonatype.iq.artifactory.FirewallProperties.MODE.quarantine

class RepositoryManagerTest
    extends Specification
{
  Logger logger = Mock()

  FirewallProperties firewallProperties

  FirewallRepositories firewallRepositories

  HostedRepositories hostedRepositories

  IqConnectionManager iqConnectionManager

  Repositories repositories = Mock(Repositories)

  StorageManager storageManager

  RepositoryManager repositoryManager

  TelemetrySupplier telemetrySupplier = Mock()

  Map defaultProperties = [
      'firewall.iq.url'              : 'http://localhost:8072',
      'firewall.iq.username'         : 'admin',
      'firewall.iq.password'         : 'admin123',
      'firewall.repo.main-java-libs' : 'quarantine',
      'firewall.repo.other-java-libs': 'audit',
      'firewall.repo.foo-cache'      : 'audit',
      'firewall.repo.test-repo-pccs' : 'policyCompliantComponentSelection'
  ]

  def 'test init - repo not found'() {
    given:
      setupMocks(['firewall.repo.foo': 'quarantine'])

    when:
      repositoryManager.loadRepositoriesFromProperties()

    then:
      1 * repositories.getRepositoryConfiguration(_) >> null
      1 * logger.warn('Repository \'foo\' was not found in Artifactory. Skipping...')
      0 * iqConnectionManager._
  }

  @Unroll
  def 'test init - repos loaded from storage'() {
    setup:
      setupMocks([:])
      repositories.remoteRepositories >> ['foo', 'bar', 'baz']
      repositories.localRepositories >> ['hostedRepo']

    when:
      repositoryManager.loadRepositoriesFromStorage()
      def repository = isRemote
          ? firewallRepositories.getEnabledOrDisabledFirewallRepoByKey(repoKey)
          : hostedRepositories.repos[repoKey]

    then:
      repository != null
      repository.repoKey == repoKey
      repository.mode == mode
      1 * storageManager.getFirewallMode(repoKey) >> mode
      1 * repositories.getRepositoryConfiguration(repoKey) >> getMockRepositoryConfiguration(repoKey, isRemote ? 'remote' : 'local')
      1 * logger.warn("Repository configuration for '${repoKey}' in mode '${mode}' missing from firewall.properties")

    where:
      repoKey      | mode        | isRemote
      'foo'        | quarantine  | true
      'bar'        | audit       | true
      'baz'        | disabled    | true
      'hostedRepo' | proprietary | false
  }

  @Unroll
  def 'test init - repos loaded from storage do not override firewall.properties'() {
    setup:
      setupMocks([
          'firewall.repo.foo'        : 'quarantine',
          'firewall.repo.bar'        : 'audit',
          'firewall.repo.baz'        : 'disabled',
          'firewall.repo.hostedRepo' : 'proprietary',
          'firewall.repo.pccsRepo'   : 'policyCompliantComponentSelection'
      ])
      repositories.remoteRepositories >> ['foo', 'bar', 'baz', 'pccsRepo']
      repositories.localRepositories >> ['hostedRepo']

    when: 'repositories are loaded from properties'
      repositoryManager.loadRepositoriesFromProperties()
      def repositoryAfterLoadFromProperties = isRemote
        ? firewallRepositories.getEnabledOrDisabledFirewallRepoByKey(repoKey)
        : hostedRepositories.repos[repoKey]

    then: 'the repo repository is in audit mode'
      repositoryAfterLoadFromProperties.repoKey == repoKey
      repositoryAfterLoadFromProperties.mode == mode
      repositories.getRepositoryConfiguration(repoKey) >>
          getMockRepositoryConfiguration(repoKey, isRemote ? 'remote' : 'local', format)

    when: 'repositories are loaded from storage afterwards'
      repositoryManager.loadRepositoriesFromStorage()
      def repositoryAfterLoadFromStorage = isRemote
          ? firewallRepositories.getEnabledOrDisabledFirewallRepoByKey(repoKey)
          : hostedRepositories.repos[repoKey]

    then: 'the repo repository is still in audit mode even though in storage it is marked as something else'
      repositoryAfterLoadFromProperties.is(repositoryAfterLoadFromStorage)
      repositoryAfterLoadFromStorage.repoKey == repoKey
      repositoryAfterLoadFromStorage.mode == mode
      1 * storageManager.getFirewallMode(repoKey) >> modeInStorage

    where:
      repoKey      | mode                              | modeInStorage | isRemote | format
      'foo'        | quarantine                        | audit         | true     | 'maven'
      'bar'        | audit                             | quarantine    | true     | 'maven'
      'baz'        | disabled                          | quarantine    | true     | 'maven'
      'pccsRepo'   | policyCompliantComponentSelection | quarantine    | true     | 'npm'
      'pccsRepo'   | quarantine                        | quarantine    | true     | 'maven'
      'hostedRepo' | proprietary                       | disabled      | false    | 'maven'
  }

  @Unroll
  def 'test init - only remote repos supported'() {
    given:
      setupMocks(['firewall.repo.foo': mode])
      RepositoryConfiguration repositoryConfiguration = getMockRepositoryConfiguration('foo', type)

    when:
      repositoryManager.loadRepositoriesFromProperties()

    then:
      1 * repositories.getRepositoryConfiguration(_) >> repositoryConfiguration
      1 * logger.warn(
          "Repository 'foo' is not a supported type. Found type '$type', but '$mode' mode can only be enabled " +
              "on type '${type == 'remote' ? 'local' : 'remote'}'. Skipping...")
      0 * iqConnectionManager._

    where:
      mode                                | type
      'quarantine'                        | 'local'
      'policyCompliantComponentSelection' | 'local'
      'proprietary'                       | 'remote'
  }

  def 'test init - verify enabling on cache repo happens against the real'() {
    given:
      setupMocks(['firewall.repo.foo-cache': 'quarantine'])
      RepositoryConfiguration repositoryConfiguration = getMockRepositoryConfiguration('foo')

    when:
      repositoryManager.loadRepositoriesFromProperties()
      repositoryManager.enableRepositoriesInIq()

    then:
      // note - first an attempt on 'foo-cache', then 'foo'. Only 'foo' call to IQ.
      1 * repositories.getRepositoryConfiguration('foo-cache') >> repositoryConfiguration
      1 * repositories.getRepositoryConfiguration('foo') >> repositoryConfiguration
      1 * iqConnectionManager.enableQuarantine('foo')
      0 * iqConnectionManager.enableQuarantine(_)
      firewallRepositories.count() == 2 // note two items in map as it contains a key for both cache and normal names
  }

  def 'test init - repositories enabled in IQ'() {
    given:
      setupMocks(['firewall.repo.foo': 'quarantine', 'firewall.repo.bar': 'audit',
                  'firewall.repo.pccs': 'policyCompliantComponentSelection'])
      RepositoryConfiguration fooRepositoryConfiguration = getMockRepositoryConfiguration('foo')
      RepositoryConfiguration barRepositoryConfiguration = getMockRepositoryConfiguration('bar')
      RepositoryConfiguration pccsRepositoryConfiguration = getMockRepositoryConfiguration('pccs')

    when:
      repositoryManager.loadRepositoriesFromProperties()
      repositoryManager.enableRepositoriesInIq()

    then:
      1 * repositories.getRepositoryConfiguration('foo') >> fooRepositoryConfiguration
      1 * repositories.getRepositoryConfiguration('bar') >> barRepositoryConfiguration
      1 * repositories.getRepositoryConfiguration('pccs') >> pccsRepositoryConfiguration
      1 * iqConnectionManager.enableQuarantine('foo')
      1 * iqConnectionManager.enableAudit('bar')
      1 * iqConnectionManager.enableQuarantine('pccs')
      firewallRepositories.count() == 6 // 2 for each = 6. One for real name, the other for cache name.
  }

  def 'test init - IQ enable failure still has repos'() {
    given:
      setupMocks(['firewall.repo.foo': 'quarantine'])
      RepositoryConfiguration fooRepositoryConfiguration = getMockRepositoryConfiguration('foo')

    when:
      repositoryManager.loadRepositoriesFromProperties()
      repositoryManager.enableRepositoriesInIq()

    then:
      1 * repositories.getRepositoryConfiguration('foo') >> fooRepositoryConfiguration
      1 * iqConnectionManager.enableQuarantine(_) >> { throw new RuntimeException('cannot connect to IQ!') }
      firewallRepositories.count() == 2
  }

  def 'test firewall enabled modes'() {
    given:
      setupMocks([
          'firewall.repo.foo': 'quarantine',
          'firewall.repo.bar': 'audit',
          'firewall.repo.pccs-not-npm': 'policyCompliantComponentSelection',
          'firewall.repo.pccs-npm': 'policyCompliantComponentSelection'])
      RepositoryConfiguration fooRepositoryConfiguration = getMockRepositoryConfiguration('foo')
      RepositoryConfiguration barRepositoryConfiguration = getMockRepositoryConfiguration('bar')
      RepositoryConfiguration pccsNotNpmRepositoryConfiguration = getMockRepositoryConfiguration('pccs-not-npm')
      RepositoryConfiguration pccsNpmRepositoryConfiguration =
          getMockRepositoryConfiguration('pccs-npm', 'remote','npm')

    when:
      repositoryManager.loadRepositoriesFromProperties()

    then:
      1 * repositories.getRepositoryConfiguration('foo') >> fooRepositoryConfiguration
      1 * repositories.getRepositoryConfiguration('bar') >> barRepositoryConfiguration
      1 * repositories.getRepositoryConfiguration('pccs-not-npm') >> pccsNotNpmRepositoryConfiguration
      1 * repositories.getRepositoryConfiguration('pccs-npm') >> pccsNpmRepositoryConfiguration

      repositoryManager.isFirewallEnabledForRepo('foo')
      repositoryManager.isQuarantineEnabledForRepo('foo')
      !repositoryManager.isPolicyCompliantComponentSelectionEnabledForRepo('foo')

      repositoryManager.isFirewallEnabledForRepo('bar')
      !repositoryManager.isQuarantineEnabledForRepo('bar')
      !repositoryManager.isPolicyCompliantComponentSelectionEnabledForRepo('bar')

      repositoryManager.isFirewallEnabledForRepo('pccs-not-npm')
      repositoryManager.isQuarantineEnabledForRepo('pccs-not-npm')
      !repositoryManager.isPolicyCompliantComponentSelectionEnabledForRepo('pccs-not-npm')

      repositoryManager.isFirewallEnabledForRepo('pccs-npm')
      repositoryManager.isQuarantineEnabledForRepo('pccs-npm')
      repositoryManager.isPolicyCompliantComponentSelectionEnabledForRepo('pccs-npm')
  }

  def 'test enabled timestamp is start time'() {
    def startTime = Date.parse(StorageManager.TIMESTAMP_FORMAT, '2019-02-20 20:20:20.000 +0000')

    given:
      setupMocks(['firewall.repo.foo': 'quarantine'])
      RepositoryConfiguration fooRepositoryConfiguration = getMockRepositoryConfiguration('foo')
      repositoryManager.startTime = startTime

    when:
      repositoryManager.loadRepositoriesFromProperties()
      repositoryManager.enableRepositoriesInIq()
      repositoryManager.verifyFirewallEnabled()

    then:
      1 * repositories.getRepositoryConfiguration('foo') >> fooRepositoryConfiguration
      1 * storageManager.markFirewallEnabledIfNecessary('foo', startTime)
  }

  def 'test iq repository url set on verify for quarantine enabled'() {
    given:
      setupMocks(['firewall.repo.foo': 'quarantine'])
      RepositoryConfiguration fooRepositoryConfiguration = getMockRepositoryConfiguration('foo')

    when:
      repositoryManager.loadRepositoriesFromProperties()
      repositoryManager.enableRepositoriesInIq()
      repositoryManager.verifyRepositoryInitProperties()

    then:
      1 * repositories.getRepositoryConfiguration('foo') >> fooRepositoryConfiguration
      1 * storageManager.setIqRepositoryUrl('foo', '/test/summary')
  }

  def 'test iq repository url set on verify for policyCompliantComponentSelection enabled'() {
    given:
      setupMocks(['firewall.repo.foo': 'policyCompliantComponentSelection'])
      RepositoryConfiguration fooRepositoryConfiguration = getMockRepositoryConfiguration('foo')

    when:
      repositoryManager.loadRepositoriesFromProperties()
      repositoryManager.enableRepositoriesInIq()
      repositoryManager.verifyRepositoryInitProperties()

    then:
      1 * repositories.getRepositoryConfiguration('foo') >> fooRepositoryConfiguration
      1 * storageManager.setIqRepositoryUrl('foo', '/test/summary')
  }

  def 'test iq repository url set on verify for audit enabled'() {
    given:
      setupMocks(['firewall.repo.foo': 'audit'])
      RepositoryConfiguration fooRepositoryConfiguration = getMockRepositoryConfiguration('foo')

    when:
      repositoryManager.loadRepositoriesFromProperties()
      repositoryManager.enableRepositoriesInIq()
      repositoryManager.verifyRepositoryInitProperties()

    then:
      1 * repositories.getRepositoryConfiguration('foo') >> fooRepositoryConfiguration
      1 * storageManager.setIqRepositoryUrl('foo', '/test/summary')
  }

  @Unroll
  def 'test iq repository mode set'() {
    given:
      setupMocks([
          'firewall.repo.foo'       : 'audit',
          'firewall.repo.bar'       : 'quarantine',
          'firewall.repo.baz'       : 'disabled',
          'firewall.repo.hostedRepo': 'proprietary',
          'firewall.repo.pccsRepo'  : 'policyCompliantComponentSelection'
      ])

    when:
      repositoryManager.loadRepositoriesFromProperties()
      repositoryManager.enableRepositoriesInIq()
      repositoryManager.saveHostedRepositories()
      repositoryManager.verifyRepositoryInitProperties()

    then:
      1 * repositories.getRepositoryConfiguration(repoKey) >>
          getMockRepositoryConfiguration(repoKey, mode == 'proprietary' ? 'local' : 'remote', format)
      1 * storageManager.setFirewallMode(repoKey, mode)

    where:
      repoKey      | mode                                | format
      'foo'        | 'audit'                             | 'maven'
      'bar'        | 'quarantine'                        | 'maven'
      'hostedRepo' | 'proprietary'                       | 'maven'
      'pccsRepo'   | 'quarantine'                        | 'maven'
      'pccsRepo'   | 'policyCompliantComponentSelection' | 'npm'
  }

  @Unroll
  def 'test firewall properties removed'() {
    given:
      setupMocks([
          'firewall.repo.remoteRepo': 'disabled',
          'firewall.repo.hostedRepo': 'disabled',
      ])
      repositories.getRepositoryConfiguration(repoKey) >> getMockRepositoryConfiguration(repoKey, mode == 'proprietary' ? 'local' : 'remote')
      repositoryManager.loadRepositoriesFromProperties()
      repositoryManager.enableRepositoriesInIq()
      repositoryManager.saveHostedRepositories()

    when:
      repositoryManager.disableRepositories()

    then: 'remove properties is called for the disabled repo'
      1 * storageManager.removeFirewallPropertiesFromRepository(repoKey)

    and: 'remove properties is not called for any other repo'
      0 * storageManager.removeFirewallPropertiesFromRepository(_)

    where:
      repoKey      | mode
      'remoteRepo' | 'audit'
      'hostedRepo' | 'proprietary'
  }

  def 'test repository disabled in IQ on disable'() {
    given:
      setupMocks([
          'firewall.repo.foo'           : 'audit',
          'firewall.repo.bar-audit'     : 'disabled',
          'firewall.repo.bar-quarantine': 'disabled',
          'firewall.repo.bar-pccs'      : 'disabled',
      ])
      repositories.getRepositoryConfiguration(repoKey) >> getMockRepositoryConfiguration(repoKey)
      repositoryManager.loadRepositoriesFromProperties()
      repositoryManager.enableRepositoriesInIq()

    when:
      repositoryManager.disableRepositories()

    then: 'we look at the previous quarantine mode'
      1 * storageManager.getFirewallMode(repoKey) >> mode

    and: 'if audit, disable audit is called in IQ'
      (mode == audit? 1 : 0) * iqConnectionManager.disableAudit(repoKey)

    and: 'if quarantine, disable quarantine is called in IQ'
      (mode == quarantine || mode == policyCompliantComponentSelection ? 1 : 0) *
          iqConnectionManager.disableQuarantine(repoKey)

    where:
      repoKey          | mode
      'bar-audit'      | audit
      'bar-quarantine' | quarantine
      'bar-pccs'       | policyCompliantComponentSelection
  }

  void setupMocks(final Map<String, String> propertiesMap = defaultProperties) {
    firewallRepositories = new FirewallRepositories()
    hostedRepositories = new HostedRepositories()

    Properties properties = new Properties()
    properties.putAll(propertiesMap)
    firewallProperties = FirewallProperties.load(properties, logger)

    iqConnectionManager = Mock(IqConnectionManager, constructorArgs: [Mock(RestClientFactory), Mock(
        RestClientConfiguration), firewallRepositories, telemetrySupplier, logger])

    iqConnectionManager.getPolicyEvaluationSummary(_) >> TestHelper.createRepositoryPolicyEvaluationSummary()

    storageManager = Mock(StorageManager, constructorArgs: [repositories, Mock(PathFactory), firewallRepositories, logger])

    repositoryManager = new RepositoryManager(logger, repositories, firewallProperties, iqConnectionManager,
        storageManager, firewallRepositories, hostedRepositories)
  }

  RepositoryConfiguration getMockRepositoryConfiguration(
      final String repoKey,
      final String type = 'remote',
      String format = 'maven') {
    RepositoryConfiguration repositoryConfiguration = Mock(RepositoryConfiguration)
    repositoryConfiguration.getKey() >> repoKey
    repositoryConfiguration.getType() >> type
    repositoryConfiguration.getPackageType() >> format
    return repositoryConfiguration
  }
}
