/*
 * Copyright (c) 2019-present Sonatype, Inc. All rights reserved.
 * Includes the third-party code listed at http://links.sonatype.com/products/nexus/attributions.
 * "Sonatype" is a trademark of Sonatype, Inc.
 */
package com.sonatype.iq.artifactory.audit

import java.util.concurrent.ExecutionException
import java.util.concurrent.TimeUnit

import com.sonatype.iq.artifactory.FirewallProperties.MODE
import com.sonatype.iq.artifactory.FirewallRepository
import com.sonatype.iq.artifactory.IqConnectionException
import com.sonatype.iq.artifactory.IqConnectionManager
import com.sonatype.iq.artifactory.StorageManager

import com.google.common.util.concurrent.ListenableFuture
import spock.lang.Specification
import spock.lang.Subject

import static com.sonatype.iq.artifactory.TestHelper.createFirewallRepository
import static org.awaitility.Awaitility.await

class AuditExecutorTest
    extends Specification
{
  StorageManager storageManager = Mock()

  IqConnectionManager iqConnectionManager = Mock()

  FirewallRepository firewallRepository = createFirewallRepository('testKey', MODE.audit)

  @Subject
  AuditExecutor auditExecutor = new AuditExecutor(iqConnectionManager, storageManager)

  def 'task execution returns a result when successful'() {
    given:
      def assets = []

    when:
      ListenableFuture<AuditResult> future = auditExecutor.auditRepository(firewallRepository, assets)
      await().atMost(1, TimeUnit.SECONDS).until({ future.isDone() })

    then:
      AuditResult auditResult = future.get()
      auditResult.componentCount == 0
  }

  def 'task execution with failure'() {
    given:
      def assets = []
      IqConnectionException iqConnectionException = new IqConnectionException('test', null)

    when:
      ListenableFuture<AuditResult> future = auditExecutor.auditRepository(firewallRepository, assets)
      await().atMost(1, TimeUnit.SECONDS).until({ future.isDone() })
      future.get()

    then:
      1 * iqConnectionManager.evaluateWithAudit(firewallRepository, assets) >> { throw iqConnectionException }
      ExecutionException outer = thrown()
      outer.cause == iqConnectionException
  }
}
