/*
 * Copyright (c) 2019-present Sonatype, Inc. All rights reserved.
 * Includes the third-party code listed at http://links.sonatype.com/products/nexus/attributions.
 * "Sonatype" is a trademark of Sonatype, Inc.
 */
package com.sonatype.iq.artifactory

import groovy.transform.ToString
import org.artifactory.repo.RepoPath

@ToString
class TestRepoPath implements RepoPath
{
  String repoKey

  String path

  String id

  String name

  RepoPath parent

  boolean file

  boolean folder

  @Override
  String toPath() {
    throw new RuntimeException("TODO - do we really need this?")
  }

  boolean isRoot() {
    return parent == null
  }

  static TestRepoPath createFileInstance(String repoKey, String path) {
    def parent = new TestRepoPath()
    parent.repoKey = repoKey
    parent.path = repoKey
    parent.name = repoKey
    parent.id = repoKey

    def result = new TestRepoPath()
    result.repoKey = repoKey
    result.path = path
    result.id = repoKey + ':' + path
    result.name = path
    result.file = true
    result.parent = parent

    return result
  }
}
