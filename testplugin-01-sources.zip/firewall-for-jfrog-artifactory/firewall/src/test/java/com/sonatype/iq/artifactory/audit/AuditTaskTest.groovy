/*
 * Copyright (c) 2019-present Sonatype, Inc. All rights reserved.
 * Includes the third-party code listed at http://links.sonatype.com/products/nexus/attributions.
 * "Sonatype" is a trademark of Sonatype, Inc.
 */
package com.sonatype.iq.artifactory.audit

import java.time.Duration
import java.time.LocalDateTime
import java.time.temporal.Temporal

import com.sonatype.iq.artifactory.FirewallArtifactoryAsset
import com.sonatype.iq.artifactory.FirewallProperties.MODE
import com.sonatype.iq.artifactory.FirewallRepository
import com.sonatype.iq.artifactory.IqConnectionManager
import com.sonatype.iq.artifactory.StorageManager

import org.artifactory.repo.RepoPath
import spock.lang.Specification

import static com.sonatype.iq.artifactory.TestHelper.createFirewallRepository


class AuditTaskTest
    extends Specification
{
  
  FirewallRepository firewallRepository = createFirewallRepository('testKey', MODE.audit)

  StorageManager storageManager = Mock()

  IqConnectionManager iqConnectionManager = Mock()

  RepoPath repoPath = Mock()
  
  def 'task will call IQ and update local state'()
  {
    given: 'two assets to audit'
      Temporal start = LocalDateTime.now()
      def assets = [
          new FirewallArtifactoryAsset(repoPath, 'hash1', true /* isNew */),
          new FirewallArtifactoryAsset(repoPath, 'hash2', true /* isNew */)
      ]

      AuditTask task = new AuditTask(firewallRepository, assets, storageManager, iqConnectionManager)

    when: 'we run the task'
      AuditResult result = task.call()
      sleep(100)
      Temporal finish = LocalDateTime.now()

    then:
      1 * iqConnectionManager.evaluateWithAudit(firewallRepository, assets)
      2 * storageManager.assignAuditTimestamp(repoPath)
      result.duration.compareTo(Duration.between(start, finish)) < 0
      result.componentCount == 2
      result.repository == 'testKey'
  }
  
}
