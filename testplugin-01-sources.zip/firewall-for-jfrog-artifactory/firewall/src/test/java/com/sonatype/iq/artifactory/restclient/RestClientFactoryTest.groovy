/*
 * Copyright (c) 2019-present Sonatype, Inc. All rights reserved.
 * Includes the third-party code listed at http://links.sonatype.com/products/nexus/attributions.
 * "Sonatype" is a trademark of Sonatype, Inc.
 */
package com.sonatype.iq.artifactory.restclient

import com.sonatype.clm.dto.model.component.RepositoryComponentEvaluationDataRequestList
import com.sonatype.insight.brain.client.ConfigurationClient
import com.sonatype.iq.artifactory.restclient.RestClient.Repository
import com.sonatype.iq.artifactory.restclient.RestClientFactory.BaseClient

import spock.lang.Specification
import spock.lang.Subject
import spock.lang.Unroll

import static com.sonatype.iq.artifactory.restclient.RepositoryManagerType.ARTIFACTORY

class RestClientFactoryTest
    extends Specification
{
  @Subject
  RestClientFactory restClientFactory = new RestClientFactory()

  RestClientConfiguration restClientConfiguration = new RestClientConfiguration()
      .setServerUrl('http://example.com/')

  @Unroll
  def 'calls #wrappedMethod on configurationClient'() {
    given: 'real restClient with mode configuration client'
      def client = restClientFactory.forConfiguration(restClientConfiguration) as BaseClient
      client.configurationClientFactory = Mock(Closure)
      def mockConfigurationClient = Mock(ConfigurationClient)
      client.configurationClientFactory.call() >> mockConfigurationClient

    when: 'rest client method is invoked'
      client."${wrappedMethod}"(*args)

    then: 'configuration client is invoked'
      if (args) {
        1 * mockConfigurationClient."${wrappedMethod}"({ [it] == args })
      }
      else {
        1 * mockConfigurationClient."${wrappedMethod}"()
      }

    where:
      wrappedMethod               | args
      'validateConfiguration'     | []
      'validateServerVersion'     | ['123']
      'getFirewallIgnorePatterns' | []
  }

  @Unroll
  def 'calls #wrappedMethod on firewallClient'() {
    given: 'real restClient with mocked firewall client'
      def client = restClientFactory.forConfiguration(restClientConfiguration).forRepository('instanceId', 'repoId',
          ARTIFACTORY) as Repository
      client.firewallClientFactory = Mock(Closure)
      def mockFirewallClient = Mock(Repository)
      client.firewallClientFactory.call() >> mockFirewallClient

    when: 'rest client method is invoked'
      client."${wrappedMethod}"(*args)

    then: 'firewall client is invoked'
      if (args) {
        1 * mockFirewallClient."${wrappedMethod}"({ [it] == args })
      }
      else {
        1 * mockFirewallClient."${wrappedMethod}"()
      }

    where:
      wrappedMethod                     | args
      'setEnabled'                      | [true]
      'setQuarantine'                   | [true]
      'evaluateComponents'              | [Mock(RepositoryComponentEvaluationDataRequestList)]
      'evaluateComponentWithQuarantine' | [Mock(RepositoryComponentEvaluationDataRequestList)]
      'evaluateComponentMetadata'       | [Mock(RepositoryComponentEvaluationDataRequestList)]
      'getPolicyEvaluationSummary'      | []
      'removeComponent'                 | ['pathname']
      'getUnquarantinedComponents'      | [1616161616]
  }
}
