/*
 * Copyright (c) 2019-present Sonatype, Inc. All rights reserved.
 * Includes the third-party code listed at http://links.sonatype.com/products/nexus/attributions.
 * "Sonatype" is a trademark of Sonatype, Inc.
 */
package com.sonatype.iq.artifactory

import org.artifactory.repo.RepoPath

class TestPathFactory
  implements PathFactory
{
  @Override
  RepoPath createRepoPath(final String path) {
    TestRepoPath repoPath = new TestRepoPath()
    repoPath.repoKey = path
    repoPath.path = path
    repoPath.id = path
    return repoPath
  }

  @Override
  RepoPath createRepoPath(final String repoKey, final String path) {
    TestRepoPath repoPath = new TestRepoPath()
    repoPath.repoKey = repoKey
    repoPath.path = path
    repoPath.id = repoKey + ':' + path
    return repoPath
  }
}
