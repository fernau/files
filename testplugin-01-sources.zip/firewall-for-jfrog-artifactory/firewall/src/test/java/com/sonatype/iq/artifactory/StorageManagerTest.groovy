/*
 * Copyright (c) 2019-present Sonatype, Inc. All rights reserved.
 * Includes the third-party code listed at http://links.sonatype.com/products/nexus/attributions.
 * "Sonatype" is a trademark of Sonatype, Inc.
 */
package com.sonatype.iq.artifactory

import com.sonatype.iq.artifactory.FirewallProperties.MODE

import org.artifactory.exception.CancelException
import org.artifactory.repo.Repositories
import org.slf4j.Logger
import spock.lang.Specification
import spock.lang.Unroll

class StorageManagerTest
    extends Specification
{
  final Repositories repositories = Mock()

  final PathFactoryImpl pathFactory = Mock()

  final FirewallRepositories firewallRepositories = Mock()

  final Logger log = Mock()

  StorageManager storageManager = new StorageManager(repositories, pathFactory, firewallRepositories, log)

  def 'firewall properties cannot be modified'() {
    when:
      storageManager.checkPropertyAccess(repoName)

    then:
      CancelException thrown = thrown()
      thrown.errorCode == 403
      thrown.message == "Cannot modify read-only property '${repoName}'."

    where:
      repoName             | _
      'firewall.settings'  | _
      'firewall.something' | _
  }


  def 'non firewall properties can be modified'() {
    when:
      storageManager.checkPropertyAccess(repoName)

    then:
      noExceptionThrown()

    where:
      repoName          | _
      'other.settings'  | _
      'other.something' | _
  }

  def 'test iq repository url'() {
    setup:
      def repoPath = TestHelper.createRootRepo()
      def url = '/test/url'
      pathFactory.createRepoPath(repoPath.repoKey) >> repoPath

    when:
      storageManager.setIqRepositoryUrl(repoPath.repoKey, url)

    then:
      1 * repositories.setProperty(repoPath, StorageManager.IQ_REPOSITORY_URL, url)
  }

  def 'test remove firewall properties'() {
    setup:
      def repoPath = TestHelper.createRootRepo()
      pathFactory.createRepoPath(repoPath.repoKey) >> repoPath

    when:
      storageManager.removeFirewallPropertiesFromRepository(repoPath.repoKey)

    then:
      for (property in StorageManager.FIREWALL_PROPERTIES) {
        1 * repositories.deleteProperty(repoPath, property)
      }
  }

  def 'deletes quarantine property'() {
    setup:
      def repoPath = TestHelper.createRootRepo()
      pathFactory.createRepoPath(repoPath.repoKey) >> repoPath

    when: 'quarantine status is deleted'
      storageManager.deleteQuarantineStatus(repoPath)

    then: 'property is deleted in repository'
      1 * repositories.deleteProperty(repoPath, StorageManager.QUARANTINE)
  }

  @Unroll
  def 'parses firewall mode #storedMode'() {
    setup:
      def repoPath = TestHelper.createRootRepo()
      pathFactory.createRepoPath(repoPath.repoKey) >> repoPath
      repositories.getProperty(repoPath, 'firewall.mode') >> storedMode

    when: 'firewall mode is parsed'
      def actualMode = storageManager.getFirewallMode(repoPath.repoKey)

    then: 'expected mode is returned'
      actualMode == expectedMode

    where:
      storedMode                          || expectedMode
      'quarantine'                        || MODE.quarantine
      'audit'                             || MODE.audit
      'disabled'                          || MODE.disabled
      'policyCompliantComponentSelection' || MODE.policyCompliantComponentSelection
      'proprietary'                       || MODE.proprietary
      null                                || null
      'invalid'                           || null
  }
}
