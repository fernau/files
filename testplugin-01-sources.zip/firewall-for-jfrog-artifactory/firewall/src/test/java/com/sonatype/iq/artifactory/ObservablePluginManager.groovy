/*
 * Copyright (c) 2019-present Sonatype, Inc. All rights reserved.
 * Includes the third-party code listed at http://links.sonatype.com/products/nexus/attributions.
 * "Sonatype" is a trademark of Sonatype, Inc.
 */
package com.sonatype.iq.artifactory

import org.artifactory.exception.CancelException
import org.artifactory.fs.FileInfo
import org.artifactory.fs.ItemInfo
import org.artifactory.repo.RepoPath

import static com.sonatype.iq.artifactory.Commons.QuarantineStatus.ALLOW
import static com.sonatype.iq.artifactory.Commons.QuarantineStatus.DENY

class ObservablePluginManager
{
  final String repoKey
  final RepoPath repoPath
  final NexusFirewallForArtifactory firewall
  final StorageManager storageManager
  final String sha1
  final ItemInfo itemInfo
  final FileInfo fileInfo

  Exception lastException
  boolean wasCancelled

  ObservablePluginManager(final String repoKey,
                          final RepoPath repoPath,
                          final NexusFirewallForArtifactory firewall,
                          final StorageManager storageManager,
                          final String sha1,
                          final ItemInfo itemInfo,
                          final FileInfo fileInfo) {
    this.repoKey = repoKey
    this.repoPath = repoPath
    this.firewall = firewall
    this.storageManager = storageManager
    this.sha1 = sha1
    this.itemInfo = itemInfo
    this.fileInfo = fileInfo
  }

  def init() {
    clearLastResult()
    firewall.init()
  }

  def verifyInit() {
    firewall.verifyInit()
  }

  def getInitializationVerified() {
    return firewall.initializationVerified
  }

  boolean hasFirewallEnabledTimestamp() {
    return null != storageManager.getFirewallEnabledTimestamp(repoKey)
  }

  boolean isFirewallEnabled() {
    return firewall.repositoryManager.isFirewallEnabledForRepo(repoKey) // && null != timestamp && timestamp <= new Date()
  }

  boolean isMarkedQuarantined() {
    return DENY.name() == storageManager.repositories.getProperty(repoPath, StorageManager.QUARANTINE)
  }

  boolean isMarkedAllowed() {
    return ALLOW.name() == storageManager.repositories.getProperty(repoPath, StorageManager.QUARANTINE)
  }

  boolean hasVerifyInitRun() {
    return firewall.initializationVerified.count == 0
  }

  def onBeforeDownload() {
    clearLastResult()
    try {
      firewall.beforeDownloadHandler(repoPath)
    } catch(CancelException e) {
      wasCancelled = true
    } catch(Exception e) {
      lastException = e
    }
  }

  def clearLastResult() {
    lastException = null
  }

  boolean hasException() {
    return null != lastException
  }

  boolean wasCancelled() {
    return wasCancelled
  }
}
