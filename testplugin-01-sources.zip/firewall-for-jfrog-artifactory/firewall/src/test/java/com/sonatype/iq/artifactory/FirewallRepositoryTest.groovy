/*
 * Copyright (c) 2019-present Sonatype, Inc. All rights reserved.
 * Includes the third-party code listed at http://links.sonatype.com/products/nexus/attributions.
 * "Sonatype" is a trademark of Sonatype, Inc.
 */
package com.sonatype.iq.artifactory

import com.sonatype.iq.artifactory.FirewallProperties.MODE

import spock.lang.Specification
import spock.lang.Unroll

import static com.sonatype.iq.artifactory.FirewallProperties.MODE.audit
import static com.sonatype.iq.artifactory.FirewallProperties.MODE.quarantine
import static com.sonatype.iq.artifactory.TestHelper.createFirewallRepository

class FirewallRepositoryTest
    extends Specification
{
  @Unroll
  def 'verify repo format translation #packageType = #expectedFormat'() {
    setup:
      FirewallRepository firewallRepository = createFirewallRepository('theRepoKey', quarantine, 'remote', packageType)

    expect:
      firewallRepository.format == expectedFormat

    where:
      packageType | expectedFormat
      'maven'     | 'maven2'
      'npm'       | 'npm'
  }

  @Unroll
  def 'verify isQuarantineEnabled for mode = #mode'() {
    setup:
      FirewallRepository firewallRepository = createFirewallRepository('theRepoKey', mode, 'remote', 'npm')

    expect:
      firewallRepository.isQuarantineEnabled() == quarantineEnabled

    where:
      mode                                   | quarantineEnabled
      MODE.quarantine                        | true
      MODE.policyCompliantComponentSelection | true
      MODE.audit                             | false
      MODE.disabled                          | false
  }

  @Unroll
  def 'verify isPolicyCompliantComponentSelectionEnabled for mode = #mode'() {
    setup:
      FirewallRepository firewallRepository = createFirewallRepository('theRepoKey', mode, 'remote', 'npm')

    expect:
      firewallRepository.isPolicyCompliantComponentSelectionEnabled() == policyCompliantComponentSelectionEnabled

    where:
      mode                                   | policyCompliantComponentSelectionEnabled
      MODE.quarantine                        | false
      MODE.policyCompliantComponentSelection | true
      MODE.audit                             | false
      MODE.disabled                          | false
  }

  def 'test equality'() {
    setup:
      FirewallRepository firewallRepository1 = createFirewallRepository('one')


    expect:
      !firewallRepository1.equals(createFirewallRepository('two'))
      firewallRepository1.equals(createFirewallRepository('one'))
      firewallRepository1.equals(createFirewallRepository('one', audit))
      firewallRepository1.equals(createFirewallRepository('one', quarantine, 'local'))
  }

  def 'verify policyCompliantComponentSelection can be enabled for npm repositories'() {
    setup:
      FirewallRepository firewallRepository = createFirewallRepository('theRepoKey',
          MODE.policyCompliantComponentSelection, 'remote', 'npm')

    expect:
      firewallRepository.isPolicyCompliantComponentSelectionEnabled() == true
  }

  def 'verify policyCompliantComponentSelection fallsback to quarantine for not npm repositories'() {
    setup:
      FirewallRepository firewallRepository = createFirewallRepository('theRepoKey',
          MODE.policyCompliantComponentSelection, 'remote', 'maven')

    expect:
      firewallRepository.isPolicyCompliantComponentSelectionEnabled() == false
      firewallRepository.isQuarantineEnabled() == true
  }

}
