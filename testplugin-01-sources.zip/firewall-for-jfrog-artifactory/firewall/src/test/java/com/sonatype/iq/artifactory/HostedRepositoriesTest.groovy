/*
 * Copyright (c) 2019-present Sonatype, Inc. All rights reserved.
 * Includes the third-party code listed at http://links.sonatype.com/products/nexus/attributions.
 * "Sonatype" is a trademark of Sonatype, Inc.
 */
package com.sonatype.iq.artifactory

import com.sonatype.iq.artifactory.FirewallProperties.MODE

import spock.lang.Specification

class HostedRepositoriesTest
    extends Specification
{
  def 'test repositories correctly populated'() {
    setup:
      HostedRepositories hostedRepositories = new HostedRepositories()
      hostedRepositories.add('key', TestHelper.createHostedRepository('key'))
      hostedRepositories.add('disabledKey', TestHelper.createHostedRepository('disabledKey', MODE.disabled))

    expect:
      hostedRepositories.count() == 2
      with(hostedRepositories.repos.key) {
        repoKey == 'key'
        mode == MODE.proprietary
        format == 'maven2'
      }
      with(hostedRepositories.repos.disabledKey) {
        repoKey == 'disabledKey'
        mode == MODE.disabled
      }
  }
}
