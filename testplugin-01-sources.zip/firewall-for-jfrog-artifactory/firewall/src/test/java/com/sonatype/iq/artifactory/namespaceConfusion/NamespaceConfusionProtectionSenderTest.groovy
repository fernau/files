/*
 * Copyright (c) 2019-present Sonatype, Inc. All rights reserved.
 * Includes the third-party code listed at http://links.sonatype.com/products/nexus/attributions.
 * "Sonatype" is a trademark of Sonatype, Inc.
 */
package com.sonatype.iq.artifactory.namespaceConfusion

import java.util.concurrent.LinkedBlockingQueue

import com.sonatype.iq.artifactory.IqConnectionManager

import spock.lang.Specification
import spock.lang.Subject
import spock.lang.Unroll

class NamespaceConfusionProtectionSenderTest
    extends Specification
{
  private IqConnectionManager iqConnectionManager = Mock()

  @Subject
  private NamespaceConfusionProtectionSender namespaceConfusionProtectionSender =
      new NamespaceConfusionProtectionSender(iqConnectionManager)

  def 'batches contain the correct number of components'() {
    given:
      def nameOrNamespaces = new LinkedBlockingQueue<>((0..450).collect { new Tuple2<>(true, 'name-' + it) })

    when:
      namespaceConfusionProtectionSender.send('repoKey', 'format', nameOrNamespaces)

    then:
      4 * iqConnectionManager.addProprietaryComponentNames('repoKey', 'format', { it.size() == 100 }, { it.size() == 0 })
      1 * iqConnectionManager.addProprietaryComponentNames('repoKey', 'format', { it.size() == 51 }, { it.size() == 0 })
      0 * iqConnectionManager._
  }

  @Unroll
  def 'partitions names and namespaces and skips nulls'() {
    given:
      def nameOrNamespaces = new LinkedBlockingQueue<>(data)

    when:
      namespaceConfusionProtectionSender.send('repoKey', 'format', nameOrNamespaces)

    then:
      1 * iqConnectionManager.addProprietaryComponentNames('repoKey', 'format',
          expectedNames.toSet(), expectedNamespaces.toSet())

    where:
      // @formatter:off
      data                                                                                                                     || expectedNames                        | expectedNamespaces
      [new Tuple2(true, 'name1'), new Tuple2(false, 'namespace1'), new Tuple2(true, 'name2'), new Tuple2(false, 'namespace2')] || ['name1', 'name2']                   | ['namespace1', 'namespace2']
      [new Tuple2(true, 'name1'), new Tuple2(true, 'name2'), new Tuple2(true, 'name3'), new Tuple2(true, 'name4')]             || ['name1', 'name2', 'name3', 'name4'] | []
      [new Tuple2(true, null)]                                                                                                 || []                                   | []
      [new Tuple2(true, 'name1'), new Tuple2(true, 'name1'), new Tuple2(true, 'name2'), new Tuple2(true, 'name2')]             || ['name1', 'name2'] | []
      // @formatter:on
  }
}
