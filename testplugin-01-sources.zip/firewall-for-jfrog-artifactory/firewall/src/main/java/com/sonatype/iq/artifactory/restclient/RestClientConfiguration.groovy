/*
 * Copyright (c) 2019-present Sonatype, Inc. All rights reserved.
 * Includes the third-party code listed at http://links.sonatype.com/products/nexus/attributions.
 * "Sonatype" is a trademark of Sonatype, Inc.
 */
package com.sonatype.iq.artifactory.restclient

import com.sonatype.insight.client.utils.HttpClientUtils
import com.sonatype.insight.client.utils.HttpClientUtils.Configuration

import org.apache.http.impl.client.HttpClientBuilder

class RestClientConfiguration
{
  private final Configuration config

  RestClientConfiguration() {
    config = new Configuration()
  }

  Configuration getConfig() {
    return config
  }

  RestClientConfiguration setServerUrl(final String serverUrl) {
    config.setServerUrl(serverUrl)
    return this
  }

  RestClientConfiguration setHttpClientProvider(final HttpClientProvider httpClientProvider) {
    config.setHttpClientProvider(new HttpClientUtils.HttpClientProvider()
    {
      @Override
      HttpClientBuilder create(final Configuration config) {
        return httpClientProvider.createHttpClient(RestClientConfiguration.this)
      }
    })
    return this
  }

  static interface HttpClientProvider
  {
    HttpClientBuilder createHttpClient(RestClientConfiguration config)
  }
}
