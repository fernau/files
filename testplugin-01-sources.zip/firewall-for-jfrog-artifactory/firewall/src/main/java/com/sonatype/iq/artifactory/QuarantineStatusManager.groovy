/*
 * Copyright (c) 2019-present Sonatype, Inc. All rights reserved.
 * Includes the third-party code listed at http://links.sonatype.com/products/nexus/attributions.
 * "Sonatype" is a trademark of Sonatype, Inc.
 */
package com.sonatype.iq.artifactory

import com.sonatype.iq.artifactory.Commons.QuarantineStatus
import com.sonatype.iq.artifactory.cache.QuarantineStatusManagerStorageLoadingCache

import com.google.common.cache.LoadingCache
import com.google.common.util.concurrent.UncheckedExecutionException
import org.artifactory.repo.RepoPath
import org.slf4j.Logger

import static com.sonatype.iq.artifactory.Commons.QuarantineStatus.ALLOW

class QuarantineStatusManager
{
  final IqConnectionManager iqConnectionManager

  final FirewallRepositories firewallRepositories

  final PathFactory pathFactory

  final Logger log

  final QuarantineStatusManagerStorageLoadingCache quarantineStatusCache

  QuarantineStatusManager(
      final QuarantineStatusManagerStorageLoadingCache quarantineStatusCache,
      final IqConnectionManager iqConnectionManager,
      final FirewallRepositories firewallRepositories,
      final PathFactory pathFactory,
      final Logger log)
  {
    this.quarantineStatusCache = quarantineStatusCache
    this.iqConnectionManager = iqConnectionManager
    this.firewallRepositories = firewallRepositories
    this.pathFactory = pathFactory
    this.log = log
  }

  /**
   * Called by the beforeDownload handler. This will get the asset from the cache or load it into the cache
   * from the JFrog Artifactory artifact metadata.
   */
  QuarantineStatus getQuarantineStatus(FirewallArtifactoryAsset firewallArtifactoryAsset) {
    try {
      return quarantineStatusCache.get(firewallArtifactoryAsset)
    }
    catch (UncheckedExecutionException e) {
      throw e.cause
    }
  }

  void unQuarantine(final RepoPath repoPath) {
    def asset = new FirewallArtifactoryAsset(getNormalizedRepoPath(repoPath), false /* isNew */)
    quarantineStatusCache.put(asset, ALLOW)
  }

  /**
   * Notification to keep audit and quarantine status in sync with IQ.
   */
  void removeIqComponent(final RepoPath repoPath) {
    def asset = new FirewallArtifactoryAsset(getNormalizedRepoPath(repoPath), false /* isNew */)
    iqConnectionManager.removeComponent(asset)
    quarantineStatusCache.invalidate(asset)
  }

  private RepoPath getNormalizedRepoPath(RepoPath repoPath) {
    FirewallRepository firewallRepository = firewallRepositories.getEnabledFirewallRepoByKey(repoPath.repoKey)
    return pathFactory.createRepoPath(firewallRepository.repoKey, repoPath.path)
  }
}
