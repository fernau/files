/*
 * Copyright (c) 2019-present Sonatype, Inc. All rights reserved.
 * Includes the third-party code listed at http://links.sonatype.com/products/nexus/attributions.
 * "Sonatype" is a trademark of Sonatype, Inc.
 */
package com.sonatype.iq.artifactory;

import java.text.ParseException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;

import com.sonatype.iq.artifactory.Commons.QuarantineStatus;
import com.sonatype.iq.artifactory.FirewallProperties.MODE;

import groovy.lang.Closure;
import org.apache.http.HttpStatus;
import org.artifactory.exception.CancelException;
import org.artifactory.fs.ItemInfo;
import org.artifactory.md.Properties;
import org.artifactory.repo.RepoPath;
import org.artifactory.repo.Repositories;
import org.codehaus.groovy.runtime.DateGroovyMethods;
import org.codehaus.groovy.runtime.DefaultGroovyMethods;
import org.codehaus.groovy.runtime.DefaultGroovyStaticMethods;
import org.codehaus.groovy.runtime.StringGroovyMethods;
import org.slf4j.Logger;

import static com.sonatype.iq.artifactory.Commons.QuarantineStatus.ALLOW;
import static com.sonatype.iq.artifactory.Commons.QuarantineStatus.DENY;

public class StorageManager
{
  public static String getREPOSITORY_AUDIT_COMPLETED() {
    return REPOSITORY_AUDIT_COMPLETED;
  }

  public static String getTIMESTAMP_FORMAT() {
    return TIMESTAMP_FORMAT;
  }

  public static String[] getFIREWALL_PROPERTIES() {
    return FIREWALL_PROPERTIES;
  }

  public final Repositories getRepositories() {
    return repositories;
  }

  public final PathFactory getPathFactory() {
    return pathFactory;
  }

  public final FirewallRepositories getFirewallRepositories() {
    return firewallRepositories;
  }

  private static final String FIREWALL_PREFIX = "firewall.";

  private static final String QUARANTINE = FIREWALL_PREFIX + "quarantine";

  private static final String IQ_REPOSITORY_URL = FIREWALL_PREFIX + "iqRepositoryUrl";

  private static final String FIREWALL_MODE = FIREWALL_PREFIX + "mode";

  private static final String HASH = FIREWALL_PREFIX + "sha1";

  private static final String AUDIT_TIMESTAMP = FIREWALL_PREFIX + "auditTimestamp";

  private static final String FIREWALL_ENABLED_TIMESTAMP = FIREWALL_PREFIX + "enabledTimestamp";

  private static final String FIREWALL_QUARANTINE_LAST_UPDATED_TIMESTAMP =
      FIREWALL_PREFIX + "quarantineLastUpdatedTimestamp";

  private static final String REPOSITORY_AUDIT_COMPLETED = FIREWALL_PREFIX + "repositoryAuditCompleted";

  private static final String TIMESTAMP_FORMAT = "yyyy-MM-dd HH:mm:ss.SSS Z";

  private static final String[] FIREWALL_PROPERTIES = {
      AUDIT_TIMESTAMP,
      FIREWALL_ENABLED_TIMESTAMP,
      FIREWALL_MODE,
      FIREWALL_QUARANTINE_LAST_UPDATED_TIMESTAMP,
      IQ_REPOSITORY_URL,
      QUARANTINE,
      REPOSITORY_AUDIT_COMPLETED
  };

  private final Repositories repositories;

  private final PathFactory pathFactory;

  private final FirewallRepositories firewallRepositories;

  private final Logger log;

  public StorageManager(
      Repositories repositories,
      PathFactory pathFactory,
      FirewallRepositories firewallRepositories,
      Logger log)
  {
    this.log = log;
    this.repositories = repositories;
    this.pathFactory = pathFactory;
    this.firewallRepositories = firewallRepositories;
  }

  public Properties quarantine(RepoPath repoPath) {
    return setProperty(repoPath, QUARANTINE, DENY.name());
  }

  public Properties unQuarantine(RepoPath repoPath) {
    return setProperty(repoPath, QUARANTINE, ALLOW.name());
  }

  public QuarantineStatus maybeGetQuarantineStatus(final RepoPath repoPath) {
    String quarantineStatus = getProperty(repoPath, QUARANTINE);
    if (quarantineStatus == null) {
      return null;
    }

    return !quarantineStatus.equals(ALLOW.name()) ? DENY : ALLOW;
  }

  public String getHash(RepoPath repoPath) {
    return repositories.getFileInfo(repoPath).getSha1();
  }

  public Properties assignAuditTimestamp(RepoPath repoPath) {
    return setProperty(repoPath, AUDIT_TIMESTAMP, "" + System.currentTimeMillis());
  }

  public boolean hasAuditTimestamp(RepoPath repoPath) {
    return getProperty(repoPath, AUDIT_TIMESTAMP) != null;
  }

  public Date getFirewallEnabledTimestamp(String repo) {
    RepoPath repoPath = pathFactory.createRepoPath(repo);
    String enabledTimestamp = getProperty(repoPath, FIREWALL_ENABLED_TIMESTAMP);
    try {
      return
          null != enabledTimestamp ? DefaultGroovyStaticMethods.parse(null, TIMESTAMP_FORMAT, enabledTimestamp) : null;
    }
    catch (ParseException pe) {
      return null;
    }
  }

  public void markFirewallEnabledIfNecessary(final String repo, final Date firewallStartTimestamp) {
    Date enabledTime = getFirewallEnabledTimestamp(repo);
    if (null == enabledTime) {
      RepoPath repoPath = pathFactory.createRepoPath(repo);
      setProperty(repoPath, FIREWALL_ENABLED_TIMESTAMP, formatDate(firewallStartTimestamp.getTime()));
    }
  }

  public void setIqRepositoryUrl(final String repoKey, final String iqRepositoryUrl) {
    setProperty(pathFactory.createRepoPath(repoKey), IQ_REPOSITORY_URL, iqRepositoryUrl);
  }

  /**
   * look up the ItemInfo for the given RepoPath
   *
   * @return ItemInfo if item exists in the repo, null otherwise
   */
  public ItemInfo getItemInfo(RepoPath repoPath) {
    try {
      return repositories.getItemInfo(repoPath);
    }
    catch (Exception e) {
      return null;
    }
  }

  public void checkPropertyAccess(final String name) {
    if (name.startsWith(FIREWALL_PREFIX)) {
      throw new CancelException("Cannot modify read-only property \'" + name + "\'.", HttpStatus.SC_FORBIDDEN);
    }
  }

  public String getProperty(final RepoPath repoPath, final String property) {
    return repositories.getProperty(repoPath, property);
  }

  public Properties setProperty(final RepoPath repoPath, final String property, final String value) {
    return repositories.setProperty(repoPath, property, value);
  }

  public void deleteQuarantineStatus(final RepoPath repoPath) {
    repositories.deleteProperty(repoPath, QUARANTINE);
  }

  public Properties setQuarantineLastUpdateTimestamp(final String repo, final long timestamp) {
    RepoPath repoPath = pathFactory.createRepoPath(repo);
    return setProperty(repoPath, FIREWALL_QUARANTINE_LAST_UPDATED_TIMESTAMP, formatDate(timestamp));
  }

  public Date getFirewallLastQuarantineUpdateTimestamp(final String repo) {
    RepoPath repoPath = pathFactory.createRepoPath(repo);
    String quarantineLastUpdatedTimestamp = getProperty(repoPath, FIREWALL_QUARANTINE_LAST_UPDATED_TIMESTAMP);
    try {
      return null != quarantineLastUpdatedTimestamp ? DefaultGroovyStaticMethods
          .parse(null, TIMESTAMP_FORMAT, quarantineLastUpdatedTimestamp) : null;
    }
    catch (ParseException pe) {
      return null;
    }
  }

  /**
   * Mark with a property the time this repository completed a full audit. As a side-effect it also marks the in-memory
   * instance as audited.
   */
  public Boolean setRepositoryAudited(final FirewallRepository repo, final long timestamp) {
    RepoPath repoPath = pathFactory.createRepoPath(repo.getRepoKey());
    setProperty(repoPath, REPOSITORY_AUDIT_COMPLETED, formatDate(timestamp));
    return setAudited(repo, true);
  }

  /**
   * Look up this property directly, bypassing cache
   */
  public String getFirewallAuditPass(final String repoKey) {
    return repositories.getProperty(pathFactory.createRepoPath(repoKey), REPOSITORY_AUDIT_COMPLETED);
  }

  private String formatDate(long timestamp) {
    return DateGroovyMethods.format(new Date(timestamp), TIMESTAMP_FORMAT);
  }

  public Properties setFirewallMode(final String repoKey, final String mode) {
    return setProperty(pathFactory.createRepoPath(repoKey), FIREWALL_MODE, mode);
  }

  /**
   * Get persisted firewall mode, or <i>null</i> if no mode is set or if mode cannot be parsed
   *
   * @param repoKey repository
   * @return firewall <i>MODE</i>
   */
  public MODE getFirewallMode(final String repoKey) {
    String firewallMode = getProperty(pathFactory.createRepoPath(repoKey), FIREWALL_MODE);
    try {
      return StringGroovyMethods.asBoolean(firewallMode) ? MODE.valueOf(firewallMode) : null;
    }
    catch (IllegalArgumentException e) {
      log.warn("Unsupported firewall mode \'" + firewallMode + "\' set on repository: \'" + repoKey + "\'", e);
      return null;
    }
  }

  public String[] removeFirewallPropertiesFromRepository(final String repoKey) {
    return DefaultGroovyMethods.each(FIREWALL_PROPERTIES, new Closure<Object>(this, this)
    {
      public void doCall(Object property) {
        getRepositories().deleteProperty(getPathFactory().createRepoPath(repoKey), (String) property);
      }
    });
  }

  public static String getFIREWALL_PREFIX() {
    return FIREWALL_PREFIX;
  }

  public static String getQUARANTINE() {
    return QUARANTINE;
  }

  public static String getIQ_REPOSITORY_URL() {
    return IQ_REPOSITORY_URL;
  }

  public static String getFIREWALL_MODE() {
    return FIREWALL_MODE;
  }

  public static String getHASH() {
    return HASH;
  }

  public static String getAUDIT_TIMESTAMP() {
    return AUDIT_TIMESTAMP;
  }

  public static String getFIREWALL_ENABLED_TIMESTAMP() {
    return FIREWALL_ENABLED_TIMESTAMP;
  }

  public static String getFIREWALL_QUARANTINE_LAST_UPDATED_TIMESTAMP() {
    return FIREWALL_QUARANTINE_LAST_UPDATED_TIMESTAMP;
  }

  private static boolean setAudited(FirewallRepository propOwner, final boolean audited) {
    propOwner.setAudited(audited);
    return audited;
  }
}
