/*
 * Copyright (c) 2019-present Sonatype, Inc. All rights reserved.
 * Includes the third-party code listed at http://links.sonatype.com/products/nexus/attributions.
 * "Sonatype" is a trademark of Sonatype, Inc.
 */
package com.sonatype.iq.artifactory.restclient

import com.sonatype.clm.dto.model.component.FirewallIgnorePatterns
import com.sonatype.clm.dto.model.component.ProprietaryComponentNames
import com.sonatype.clm.dto.model.component.RepositoryComponentEvaluationDataList
import com.sonatype.clm.dto.model.component.RepositoryComponentEvaluationDataRequestList
import com.sonatype.clm.dto.model.component.UnquarantinedComponentList
import com.sonatype.clm.dto.model.policy.RepositoryPolicyEvaluationSummary
import com.sonatype.clm.dto.model.repository.QuarantinedComponentReport

interface RestClient
{
  interface Base
  {
    void validateConfiguration() throws IOException;

    void validateServerVersion(String version) throws IOException;

    Repository forRepository(final String repositoryManagerInstanceId,
                             final String repositoryPublicId,
                             final RepositoryManagerType repositoryManagerType);

    FirewallIgnorePatterns getFirewallIgnorePatterns() throws IOException;
  }

  interface Repository
  {
    void setEnabled(boolean enabled) throws IOException;

    void setQuarantine(final boolean enabled) throws IOException;

    void removeComponent(String pathname) throws IOException;

    void evaluateComponents(final RepositoryComponentEvaluationDataRequestList componentEvaluationDataRequestList)
        throws IOException;

    void addProprietaryComponentNames(final ProprietaryComponentNames componentNames) throws IOException;

    RepositoryComponentEvaluationDataList evaluateComponentWithQuarantine(
        final RepositoryComponentEvaluationDataRequestList repositoryComponentEvaluationDataRequest) throws IOException;

    RepositoryComponentEvaluationDataList evaluateComponentMetadata(
        RepositoryComponentEvaluationDataRequestList repositoryComponentEvaluationDataRequest) throws IOException;

    RepositoryPolicyEvaluationSummary getPolicyEvaluationSummary() throws IOException;

    QuarantinedComponentReport getQuarantinedComponentReportUrl(String pathname) throws IOException;

    UnquarantinedComponentList getUnquarantinedComponents(long sinceUtcTimestamp) throws IOException;
  }
}
