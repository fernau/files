/*
 * Copyright (c) 2019-present Sonatype, Inc. All rights reserved.
 * Includes the third-party code listed at http://links.sonatype.com/products/nexus/attributions.
 * "Sonatype" is a trademark of Sonatype, Inc.
 */
package com.sonatype.iq.artifactory;

import org.artifactory.exception.CancelException;

public class IqConnectionException
    extends CancelException
{
  public IqConnectionException(final String message) {
    super(message, 403);
  }

  public IqConnectionException(final String message, final Throwable cause) {
    super(message, cause, 403);
  }
}
