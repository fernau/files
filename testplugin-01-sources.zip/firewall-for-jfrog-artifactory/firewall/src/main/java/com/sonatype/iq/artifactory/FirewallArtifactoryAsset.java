/*
 * Copyright (c) 2019-present Sonatype, Inc. All rights reserved.
 * Includes the third-party code listed at http://links.sonatype.com/products/nexus/attributions.
 * "Sonatype" is a trademark of Sonatype, Inc.
 */
package com.sonatype.iq.artifactory;

import java.util.Objects;

import org.artifactory.repo.RepoPath;

/**
 * A representation of the firewall asset as stored in the JFrog Artifactory artifact metadata.
 *
 * This is also stored in the cache. An optimization will be to reduce the memory footprint for instances of this
 * class.
 */
public class FirewallArtifactoryAsset
{
  private RepoPath repoPath;

  private String hash;

  /**
   * Whether this asset is new to Artifactory. For a proxy/remote repository, an asset is new when it is downloaded.
   * This flag is important for policy evaluations in IQ, because notifications are supposed to be sent only for new
   * components.
   */
  private boolean isNew;

  public FirewallArtifactoryAsset(final RepoPath repoPath, boolean isNew) {
    this.repoPath = repoPath;
    this.isNew = isNew;
  }

  public FirewallArtifactoryAsset(final RepoPath repoPath, final String hash, boolean isNew) {
    this.repoPath = repoPath;
    this.hash = hash;
    this.isNew = isNew;
  }

  public String getId() {
    return repoPath.getId();
  }

  public String getRepoKey() {
    return repoPath.getRepoKey();
  }

  public String getPath() {
    return repoPath.getPath();
  }

  public RepoPath getRepoPath() {
    return repoPath;
  }

  public String getHash() {
    return hash;
  }

  public boolean isNew() {
    return isNew;
  }

  @Override
  public boolean equals(final Object obj) {
    if (obj == null || !getClass().equals(obj.getClass())) {
      return false;
    }

    FirewallArtifactoryAsset other = (FirewallArtifactoryAsset) obj;
    return Objects.equals(getId(), other.getId());
  }

  @Override
  public int hashCode() {
    return getId().hashCode();
  }

  @Override
  public String toString() {
    return "FirewallArtifactoryAsset [repoPath=" + repoPath + ", hash=" + hash + ", isNew=" + isNew + "]";
  }
}
