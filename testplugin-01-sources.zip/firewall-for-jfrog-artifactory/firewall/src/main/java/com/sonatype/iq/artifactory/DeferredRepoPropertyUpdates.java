/*
 * Copyright (c) 2019-present Sonatype, Inc. All rights reserved.
 * Includes the third-party code listed at http://links.sonatype.com/products/nexus/attributions.
 * "Sonatype" is a trademark of Sonatype, Inc.
 */
package com.sonatype.iq.artifactory;

import com.sonatype.iq.artifactory.FirewallProperties.MODE;

public class DeferredRepoPropertyUpdates
{
  private String repoKey;

  private MODE firewallMode;

  private String reportUrl;

  public DeferredRepoPropertyUpdates(final String repoKey, final MODE firewallMode, final String reportUrl) {
    this.repoKey = repoKey;
    this.firewallMode = firewallMode;
    this.reportUrl = reportUrl;
  }

  public String getRepoKey() {
    return repoKey;
  }

  public void setRepoKey(String repoKey) {
    this.repoKey = repoKey;
  }

  public MODE getFirewallMode() {
    return firewallMode;
  }

  public void setFirewallMode(MODE firewallMode) {
    this.firewallMode = firewallMode;
  }

  public String getReportUrl() {
    return reportUrl;
  }

  public void setReportUrl(String reportUrl) {
    this.reportUrl = reportUrl;
  }
}
