/*
 * Copyright (c) 2019-present Sonatype, Inc. All rights reserved.
 * Includes the third-party code listed at http://links.sonatype.com/products/nexus/attributions.
 * "Sonatype" is a trademark of Sonatype, Inc.
 */
package com.sonatype.iq.artifactory;

import java.util.Map;
import java.util.Objects;

import com.sonatype.iq.artifactory.FirewallProperties.MODE;

import com.google.common.collect.ImmutableMap;

/**
 * Base class for different repository types.
 */
public abstract class AbstractRepository
{
  private static final Map<String, String> repoFormatTranslation =
      ImmutableMap.of("maven", "maven2", "gems", "rubygems");

  public AbstractRepository(final String repoKey, final MODE mode, final String type, final String format) {
    this.repoKey = repoKey;
    this.mode = mode;
    this.type = type;
    this.format = format;
  }

  public String getRepoKey() {
    return repoKey;
  }

  public MODE getMode() {
    return mode;
  }

  public String getType() {
    return type;
  }

  public String getFormat() {
    return format;
  }

  public static String translateToIqFormat(final String artifactoryFormat) {
    return repoFormatTranslation.getOrDefault(artifactoryFormat, artifactoryFormat);
  }

  /**
   * Verifies the configuration of this repository.
   *
   * @return true if the instance of this class supports artifactory's backing repository type
   */
  public boolean isSupportedType() {
    return getSupportedType().equals(type);
  }

  public abstract String getSupportedType();

  public abstract boolean isHostedRepository();

  protected final String repoKey;

  protected final MODE mode;

  protected final String type;

  protected final String format;

  @Override
  public boolean equals(final Object o) {
    if (this == o) {
      return true;
    }
    if (o == null || getClass() != o.getClass()) {
      return false;
    }
    AbstractRepository that = (AbstractRepository) o;
    return Objects.equals(repoKey, that.repoKey);
  }

  public int hashCode() {
    return repoKey.hashCode();
  }

  @Override
  public String toString() {
    return "AbstractRepository{" +
        "repoKey='" + repoKey + '\'' +
        ", mode=" + mode +
        ", type='" + type + '\'' +
        ", format='" + format + '\'' +
        '}';
  }
}
