/*
 * Copyright (c) 2019-present Sonatype, Inc. All rights reserved.
 * Includes the third-party code listed at http://links.sonatype.com/products/nexus/attributions.
 * "Sonatype" is a trademark of Sonatype, Inc.
 */
package com.sonatype.iq.artifactory;

import com.sonatype.iq.artifactory.FirewallProperties.MODE;

import org.artifactory.repo.RepositoryConfiguration;

/**
 * A locally hosted artifactory repository. This type of repository cannot be used to block access to components.
 */
public class HostedRepository
    extends AbstractRepository
{
  public HostedRepository(final String repoKey, final MODE mode, final String type, final String format) {
    super(repoKey, mode, type, format);
  }

  public static HostedRepository of(final RepositoryConfiguration repositoryConfiguration, final MODE mode) {
    return new HostedRepository(repositoryConfiguration.getKey(), mode, repositoryConfiguration.getType(),
        AbstractRepository.translateToIqFormat(repositoryConfiguration.getPackageType()));
  }

  @Override
  public String getSupportedType() {
    return "local";
  }

  @Override
  public boolean isHostedRepository() {
    return true;
  }
}
