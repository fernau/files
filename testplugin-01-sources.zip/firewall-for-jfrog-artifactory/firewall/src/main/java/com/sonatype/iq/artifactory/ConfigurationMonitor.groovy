/*
 * Copyright (c) 2019-present Sonatype, Inc. All rights reserved.
 * Includes the third-party code listed at http://links.sonatype.com/products/nexus/attributions.
 * "Sonatype" is a trademark of Sonatype, Inc.
 */
package com.sonatype.iq.artifactory

import groovy.util.logging.Slf4j

@Slf4j
public class ConfigurationMonitor
{
  public static final int CONFIG_RELOAD_CHECK_INTERVAL_IN_MS = 1000

  private static volatile Thread monitorThread

  private static volatile boolean running

  static synchronized start(plugin) {
    log.info("Starting FirewallForArtifactory plugin config monitoring.")
    if (monitorThread != null) {
      throw new IllegalStateException("The FirewallForArtifactory plugin config monitor is already running")
    }

    running = true
    monitorThread = Thread.startDaemon('FirewallForArtifactory plugin config monitor') {
      log.info('Started FirewallForArtifactory plugin config monitoring.')
      while (running) {
        Thread.sleep(CONFIG_RELOAD_CHECK_INTERVAL_IN_MS)

        plugin.reloadConfigIfNeeded()
      }
    }
  }

  static synchronized stop() {
    log.info("Stopping FirewallForArtifactory plugin config monitoring.")
    running = false
    if (monitorThread != null) {
      monitorThread.join()
      monitorThread = null
    }
    log.info("Stopped FirewallForArtifactory plugin config monitoring.")
  }
}
