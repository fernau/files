/*
 * Copyright (c) 2019-present Sonatype, Inc. All rights reserved.
 * Includes the third-party code listed at http://links.sonatype.com/products/nexus/attributions.
 * "Sonatype" is a trademark of Sonatype, Inc.
 */
package com.sonatype.iq.artifactory.restclient

import com.sonatype.insight.brain.client.FirewallClient

enum RepositoryManagerType
{
  NEXUS(FirewallClient.NEXUS_RESOURCE_PATH), ARTIFACTORY(FirewallClient.ARTIFACTORY_RESOURCE_PATH);

  RepositoryManagerType(final String resourcePath) {
    this.resourcePath = resourcePath
  }

  public final String resourcePath
}
