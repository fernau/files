/*
 * Copyright (c) 2019-present Sonatype, Inc. All rights reserved.
 * Includes the third-party code listed at http://links.sonatype.com/products/nexus/attributions.
 * "Sonatype" is a trademark of Sonatype, Inc.
 */
package com.sonatype.iq.artifactory;

import java.io.InputStream;
import java.io.UncheckedIOException;
import java.io.UnsupportedEncodingException;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.util.LinkedHashMap;
import java.util.Map;

import com.sonatype.clm.dto.model.component.RepositoryComponentEvaluationData;
import com.sonatype.clm.dto.model.component.RepositoryComponentEvaluationDataList;
import com.sonatype.clm.dto.model.component.RepositoryComponentEvaluationDataRequestList;
import com.sonatype.clm.dto.model.component.RepositoryComponentEvaluationDataRequestList.RepositoryComponentEvaluationDataRequest;

import groovy.json.JsonOutput;
import groovy.json.JsonSlurper;
import org.artifactory.repo.RepoPath;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * Processes the metadata for an NPM component for Policy Compliant Component Selection.
 *
 * @since 2.5.0
 */
class NpmComponentMetadataProcessor
{
  private static final Logger log = LoggerFactory.getLogger(NpmComponentMetadataProcessor.class);

  private final IqConnectionManager iqConnectionManager;

  public NpmComponentMetadataProcessor(IqConnectionManager iqConnectionManager) {
    this.iqConnectionManager = iqConnectionManager;
  }

  /**
   * Processes the metadata for an NPM component for Policy Compliant Component Selection:
   * - downloads the component metadata from the remote/proxied repository
   * - makes a request to IQ to evaluate policies on all component versions (IQ returns a list with the
   * quarantined/allowed status for each version)
   * - removes the quarantined versions from the component metadata and returns the updated metadata
   *
   * @param pluginCtx The Artifactory plugin context
   * @param repoPath The RepoPath for the NPM component metadata
   * @param npmPackageName The NPM package name
   */
  byte[] processComponentMetadata(Object pluginCtx, RepoPath repoPath, String npmPackageName) {
    log.debug("Processing component metadata for {}", repoPath);
    long start = System.currentTimeMillis();

    Object componentMetadataJson = downloadComponentMetadataJson(pluginCtx, repoPath, npmPackageName);
    Map<String, Object> componentMetadataJsonMap = (Map) componentMetadataJson;

    Map<String, Object> versions = (Map) componentMetadataJsonMap.get("versions");
    RepositoryComponentEvaluationDataRequestList repositoryComponentEvaluationDataRequestList =
        buildRepositoryComponentEvaluationDataRequestList(npmPackageName, versions);
    repositoryComponentEvaluationDataRequestList.components.forEach(
        component -> log.trace("  Pathname: {}, hash: {}", component.pathname, component.hash));

    RepositoryComponentEvaluationDataList repositoryComponentEvaluationDataList = iqConnectionManager
        .evaluateComponentMetadata(repoPath.getRepoKey(), repositoryComponentEvaluationDataRequestList);

    // Remove the quarantined versions from the component metadata
    // Using LinkedHashMap to preserve order in case it matters
    Map<String, Object> allowedVersions = new LinkedHashMap<>();
    int index = 0;
    for (String version : versions.keySet()) {
      RepositoryComponentEvaluationData repositoryComponentEvaluationData =
          repositoryComponentEvaluationDataList.componentEvalResults.get(index);
      log.trace("  Version: {} is allowed: {}", version, !repositoryComponentEvaluationData.quarantine);
      if (!repositoryComponentEvaluationData.quarantine) {
        allowedVersions.put(version, versions.get(version));
      }
      index++;
    }
    componentMetadataJsonMap.put("versions", allowedVersions);

    try {
      byte[] result = new JsonOutput().toJson(componentMetadataJsonMap).getBytes("UTF-8");
      log.debug("Processed component metadata for {} in {} ms", repoPath, System.currentTimeMillis() - start);
      return result;
    }
    catch (UnsupportedEncodingException e) {
      throw new UncheckedIOException(e);
    }
  }

  private RepositoryComponentEvaluationDataRequestList buildRepositoryComponentEvaluationDataRequestList(
      String npmPackageName,
      Map<String, Object> versions)
  {
    RepositoryComponentEvaluationDataRequestList repositoryComponentEvaluationDataRequestList =
        new RepositoryComponentEvaluationDataRequestList();

    repositoryComponentEvaluationDataRequestList.cause =
        RepositoryComponentEvaluationDataRequestList.COMPONENT_METADATA;

    String npmPackageId = getNpmPackageId(npmPackageName);
    String npmPackagePathPrefix = "/" + npmPackageName + "/-/" + npmPackageId + "-";
    for (String version : versions.keySet()) {
      RepositoryComponentEvaluationDataRequest repositoryComponentEvaluationDataRequest =
          new RepositoryComponentEvaluationDataRequest();
      repositoryComponentEvaluationDataRequest.format = "npm";
      repositoryComponentEvaluationDataRequest.hash = getComponentHash((Map) versions.get(version));
      repositoryComponentEvaluationDataRequest.pathname = npmPackagePathPrefix + version + ".tgz";

      repositoryComponentEvaluationDataRequestList.components.add(repositoryComponentEvaluationDataRequest);
    }

    return repositoryComponentEvaluationDataRequestList;
  }

  private String getComponentHash(Map<String, Object> componentVersion) {
    Map<String, Object> distMap = (Map) componentVersion.get("dist");
    return (String) distMap.get("shasum");
  }

  private String getNpmPackageId(String npmPackageName) {
    int slashAt = npmPackageName.indexOf('/');
    if (slashAt < 0) {
      return npmPackageName;
    }

    return npmPackageName.substring(slashAt + 1);
  }

  private Map<String, Object> downloadComponentMetadataJson(
      Object pluginCtx,
      RepoPath repoPath,
      String npmPackageName)
  {
    try {
      Object internalRepository = getInternalRepository(pluginCtx, repoPath);

      Method downloadResourceMethod = internalRepository.getClass().getDeclaredMethod("downloadResource", String.class);
      Object streamHandle = downloadResourceMethod.invoke(internalRepository, npmPackageName);
      try {
        Method getInputStreamMethod = streamHandle.getClass().getDeclaredMethod("getInputStream");
        InputStream is = (InputStream) getInputStreamMethod.invoke(streamHandle);
        if (is == null) {
          throw new RuntimeException("Cannot get content for " + npmPackageName);
        }
        Object json = new JsonSlurper().parse(is);
        return (Map) json;
      }
      finally {
        closeStreamHandle(streamHandle);
      }
    }
    catch (Exception e) {
      throw new RuntimeException(e);
    }
  }

  private Object getInternalRepository(
      Object pluginCtx,
      RepoPath repoPath) throws ClassNotFoundException, NoSuchMethodException, InvocationTargetException, IllegalAccessException
  {
    Class internalRepositoryServiceClass = Class.forName("org.artifactory.repo.service.InternalRepositoryService");

    Method beanForTypeMethod = pluginCtx.getClass().getDeclaredMethod("beanForType", Class.class);
    Object internalRepositoryService = beanForTypeMethod.invoke(pluginCtx, internalRepositoryServiceClass);

    Method remoteRepositoryByKeyMethod =
        internalRepositoryServiceClass.getMethod("remoteRepositoryByKey", String.class);
    return remoteRepositoryByKeyMethod.invoke(internalRepositoryService, repoPath.getRepoKey());
  }

  private void closeStreamHandle(
      Object streamHandle) throws ClassNotFoundException, NoSuchMethodException, InvocationTargetException, IllegalAccessException
  {
    Method closeMethod = streamHandle.getClass().getDeclaredMethod("close");
    closeMethod.invoke(streamHandle);
  }
}
