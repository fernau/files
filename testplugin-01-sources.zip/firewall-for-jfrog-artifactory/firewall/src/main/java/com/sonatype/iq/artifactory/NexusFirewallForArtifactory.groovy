/*
 * Copyright (c) 2019-present Sonatype, Inc. All rights reserved.
 * Includes the third-party code listed at http://links.sonatype.com/products/nexus/attributions.
 * "Sonatype" is a trademark of Sonatype, Inc.
 */
package com.sonatype.iq.artifactory

import com.sonatype.clm.dto.model.policy.RepositoryPolicyEvaluationSummary

import org.artifactory.repo.RepoPath

trait NexusFirewallForArtifactory
{
  abstract void init()

  String getPluginVersion() {
    // note: this only returns a value when bundled as a jar (i.e. in a live environment). Tests will return 'unknown'
    return this.getClass().getPackage()?.getImplementationVersion() ?: 'unknown'
  }

  abstract void loadIgnorePatterns()

  abstract RepositoryPolicyEvaluationSummary getFirewallEvaluationSummary(String repositoryName)

  abstract void beforeDownloadHandler(final RepoPath repoPath)

  abstract byte[] altRemoteContentHandler(def ctx, RepoPath repoPath)

  abstract void altRemotePathHandler(RepoPath repoPath)

  abstract void afterDeleteHandler(RepoPath repoPath)

  abstract void verifyInit()

  abstract void propertyEventHandler(final String name)

  abstract def getIgnorePatternReloadCronExpression()

  abstract void auditRepositories()

  abstract String getNamespaceConfusionProtectionJobCronExpression()

  abstract void namespaceConfusionProtectionJobHandler()

  abstract String getInitializationJobCronExpression()

  abstract void initializationJobHandler()

  /**
   * Determine if the plugin initialization state is such that component requests can be correctly evaluated.
   */
  abstract boolean isReady()

  /**
   * Checks initialisation status.
   *
   * @return true if the initialisation has been started, otherwise false
   */
  abstract boolean isInitializationRequired()
}
