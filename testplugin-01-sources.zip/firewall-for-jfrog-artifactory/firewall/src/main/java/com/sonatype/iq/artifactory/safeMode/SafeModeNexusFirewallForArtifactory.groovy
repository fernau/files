/*
 * Copyright (c) 2019-present Sonatype, Inc. All rights reserved.
 * Includes the third-party code listed at http://links.sonatype.com/products/nexus/attributions.
 * "Sonatype" is a trademark of Sonatype, Inc.
 */
package com.sonatype.iq.artifactory.safeMode

import com.sonatype.clm.dto.model.policy.RepositoryPolicyEvaluationSummary
import com.sonatype.iq.artifactory.NexusFirewallForArtifactory

import org.apache.http.HttpStatus
import org.artifactory.exception.CancelException
import org.artifactory.repo.RepoPath
import org.slf4j.Logger

import static java.lang.String.format

/**
 * 'Safe mode' implementation of the plugin for when there is no firewall.properties configuration.
 * Puts the entire repository manager in a safe mode where no artifacts can be downloaded.
 */
class SafeModeNexusFirewallForArtifactory
    implements NexusFirewallForArtifactory
{
  public static final String CRON_NEVER = '0 0 0 ? * * 1970'
  public static final String CRON_EVERY_HOUR = "0 0 * * * ?"

  final Logger log

  private final String ATTENTION_GRABBER = "***************************************************************************"

  private final String GRABBER_LINE = "***** "

  private final String SAFE_MODE = "Nexus Firewall for Artifactory is operating in safe mode and will deny ALL " +
      "artifact requests until this problem is fixed"

  private final String reason

  SafeModeNexusFirewallForArtifactory(final String reason, final Logger log) {
    this.reason = reason
    this.log = log
  }

  @Override
  void init() {
    logError(reason)
  }

  @Override
  void loadIgnorePatterns() {
    // no-op
  }

  @Override
  RepositoryPolicyEvaluationSummary getFirewallEvaluationSummary(final String repositoryName) {
    logError("Unable to fetch Firewall evaluation summary report")
    // no-op
    return null
  }

  @Override
  void beforeDownloadHandler(final RepoPath repoPath) {
    def msg = format("Download of '%s' cancelled due to mis-configured firewall plugin", repoPath)
    logError(msg)
    throw new CancelException(msg, HttpStatus.SC_FORBIDDEN)
  }

  @Override
  byte[] altRemoteContentHandler(def ctx, RepoPath repoPath) {
    def msg = format("Download of '%s' cancelled due to mis-configured firewall plugin", repoPath)
    logError(msg)
    throw new CancelException(msg, HttpStatus.SC_FORBIDDEN)
  }

  @Override
  void altRemotePathHandler(RepoPath repoPath) {
    // no-op
  }

  @Override
  void afterDeleteHandler(RepoPath itemInfo) {
    // no-op
  }

  @Override
  void verifyInit() {
    // no-op
  }

  @Override
  void propertyEventHandler(final String name) {
    // no-op
  }

  @Override
  def getIgnorePatternReloadCronExpression() {
    return CRON_NEVER
  }

  @Override
  void auditRepositories() {
    // no-op
  }

  @Override
  String getNamespaceConfusionProtectionJobCronExpression() {
    return CRON_EVERY_HOUR
  }

  @Override
  void namespaceConfusionProtectionJobHandler() {
    // no-op
  }

  @Override
  String getInitializationJobCronExpression() {
    return CRON_NEVER
  }

  @Override
  void initializationJobHandler() {
    // no-op
  }

  @Override
  boolean isReady() {
    return true
  }

  @Override
  boolean isInitializationRequired() {
    return false
  }

  private void logError(String error) {
    log.error("""
${ATTENTION_GRABBER}
${GRABBER_LINE} ${error}
${GRABBER_LINE} ${SAFE_MODE}
${ATTENTION_GRABBER}""")
  }
}
