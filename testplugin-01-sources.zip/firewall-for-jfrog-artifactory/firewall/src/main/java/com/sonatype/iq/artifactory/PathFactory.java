/*
 * Copyright (c) 2019-present Sonatype, Inc. All rights reserved.
 * Includes the third-party code listed at http://links.sonatype.com/products/nexus/attributions.
 * "Sonatype" is a trademark of Sonatype, Inc.
 */
package com.sonatype.iq.artifactory;

import org.artifactory.repo.RepoPath;

public interface PathFactory
{
  public abstract RepoPath createRepoPath(String path);

  public abstract RepoPath createRepoPath(String repoKey, String path);
}
