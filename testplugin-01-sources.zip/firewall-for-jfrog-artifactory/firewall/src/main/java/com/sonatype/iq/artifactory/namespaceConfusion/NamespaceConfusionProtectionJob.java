/*
 * Copyright (c) 2019-present Sonatype, Inc. All rights reserved.
 * Includes the third-party code listed at http://links.sonatype.com/products/nexus/attributions.
 * "Sonatype" is a trademark of Sonatype, Inc.
 */
package com.sonatype.iq.artifactory.namespaceConfusion;

import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.concurrent.BlockingQueue;
import java.util.concurrent.LinkedBlockingQueue;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import java.util.stream.Stream;

import com.sonatype.iq.artifactory.HostedRepository;
import com.sonatype.iq.artifactory.IgnorePatternMatcher;
import com.sonatype.iq.artifactory.RepositoryManager;

import groovy.lang.Tuple2;
import org.artifactory.fs.FileLayoutInfo;
import org.artifactory.repo.RepoPath;
import org.artifactory.search.Searches;
import org.slf4j.Logger;

import static com.sonatype.iq.artifactory.FirewallProperties.MODE.proprietary;
import static java.util.function.Predicate.not;
import static java.util.stream.Collectors.partitioningBy;
import static java.util.stream.Collectors.toCollection;
import static java.util.stream.Collectors.toUnmodifiableList;

public class NamespaceConfusionProtectionJob
{
  private final RepositoryManager repositoryManager;

  private final Searches searches;

  private final IgnorePatternMatcher ignorePatternMatcher;

  private final Logger log;

  private final NamespaceConfusionProtectionSender namespaceConfusionProtectionSender;

  private final Pattern npmScopePattern = Pattern.compile("^@([^.]+)\\.(.+)$|^([^@]+)$");

  public NamespaceConfusionProtectionJob(
      final RepositoryManager repositoryManager,
      final Searches searches,
      final IgnorePatternMatcher ignorePatternMatcher,
      final NamespaceConfusionProtectionSender namespaceConfusionProtectionSender,
      final Logger log)
  {
    this.repositoryManager = repositoryManager;
    this.searches = searches;
    this.ignorePatternMatcher = ignorePatternMatcher;
    this.log = log;
    this.namespaceConfusionProtectionSender = namespaceConfusionProtectionSender;
  }

  public void synchronizeAllRepositories() {
    Map<Boolean, List<HostedRepository>> applicableRepositories = repositoryManager.getHostedRepositories().stream()
        .collect(partitioningBy(this::taskAppliesToRepository));

    if (applicableRepositories.get(false).size() > 0) {
      log.debug("Skipping repositories: " + applicableRepositories.get(false));
    }

    if (applicableRepositories.get(true).size() == 0) {
      log.info("No hosted repositories configured for namespace confusion attack protection.");
    }

    applicableRepositories.get(true).forEach(this::synchronizeRepository);
  }

  public List<String> synchronizeNewRepositories() {
    return repositoryManager.getRepositoriesWithModeChanges().keySet().stream()
        .map(repositoryManager::getHostedRepository)
        .filter(Objects::nonNull)
        .filter(this::taskAppliesToRepository)
        .map(this::synchronizeRepository)
        .collect(toUnmodifiableList());
  }

  private String synchronizeRepository(final HostedRepository hostedRepository) {
    log.info("NamespaceConfusionProtectionJob is processing repository: " + hostedRepository);

    BlockingQueue<Tuple2<Boolean, String>> nameOrNamespaces = searches.artifactsByName("*",
            hostedRepository.getRepoKey())
        .stream()
        .filter(not(repoPath -> ignorePatternMatcher.isIgnored(hostedRepository.getFormat(), repoPath)))
        .map(repoPath -> decideToUseNameOrNamespace(hostedRepository.getFormat(), repoPath))
        .filter(t -> !Objects.isNull(t.getSecond()))
        .flatMap(nameOrNamespace -> convertToIqFormat(hostedRepository.getFormat(), nameOrNamespace))
        .distinct()
        .collect(toCollection(LinkedBlockingQueue::new));

    log.trace("Sending namespace data for repo '" + hostedRepository.getRepoKey() + ": " + nameOrNamespaces);
    namespaceConfusionProtectionSender.send(hostedRepository.getRepoKey(), hostedRepository.getFormat(), nameOrNamespaces);
    return hostedRepository.getRepoKey();
  }

  /**
   * For most repository formats we use the namespace/scope/group etc. for namespace confusion protection. When
   * this attribute is not available we use the component name instead. There are cases like NPM where some components
   * use namespaces (called 'scope' in NPM which is optional) while some other components in the same repository only
   * have a component name.
   * <p>
   * This should be consistent with how NXRM handles this.
   * NXRM implements this in: FirewallProprietaryNameTaskHelper::shouldUseGroupOrNamespace
   *
   * @param format   repo format (in IQ server spelling)
   * @param repoPath the component's repo path
   * @return the name/namespace to use annotated with a boolean variable indicating if it is a name (true) or
   *         namespace (false)
   */
  private Tuple2<Boolean, String> decideToUseNameOrNamespace(final String format, final RepoPath repoPath) {
    FileLayoutInfo fileLayoutInfo = repositoryManager.getFileLayoutInfo(repoPath);

    // copied from NRXM's FirewallProprietaryNameTaskHelper::shouldUseGroupOrNamespace:
    if ("apt".equals(format)) {
      // arch is used as group
      return new Tuple2<>(true, fileLayoutInfo.getModule());
    }
    else if ("conda".equals(format)) {
      // arch is used as group
      return new Tuple2<>(true, fileLayoutInfo.getModule());
    }
    else if ("r".equals(format)) {
      // Path is used, but CRAN doesn't seem to have groups
      return new Tuple2<>(true, fileLayoutInfo.getModule());
    }
    else if ("conan".equals(format)) {
      // URL parsing provides a path but AFAICT packages on conan center do not have them.
      return new Tuple2<>(true, fileLayoutInfo.getModule());
    }

    if (fileLayoutInfo.getOrganization() == null || fileLayoutInfo.getOrganization().isBlank()) {
      if (fileLayoutInfo.getModule() == null) {
        log.debug("NamespaceConfusionProtectionJob cannot process artifact: " + fileLayoutInfo +
            " repoPath: '" + repoPath + "' because it has no organization or module data.");
      }
      return new Tuple2<>(true, fileLayoutInfo.getModule());
    }
    else {
      return new Tuple2<>(false, fileLayoutInfo.getOrganization());
    }
  }

  private Stream<Tuple2<Boolean, String>> convertToIqFormat(final String format, final Tuple2<Boolean, String> nameOrNamespace) {
    if ("npm".equals(format) && !nameOrNamespace.getFirst()) {
      String artifactoryFormattedPackageId = nameOrNamespace.getSecond();

      Matcher matcher = npmScopePattern.matcher(artifactoryFormattedPackageId);
      if (matcher.matches()) {
        String scopedNamespace = matcher.group(1);
        String unscopedName = matcher.group(3);
        return Stream.of(
            new Tuple2<>(scopedNamespace == null, scopedNamespace == null ? unscopedName : "@" + scopedNamespace));
      }
      else {
        log.debug("NamespaceConfusionProtectionJob cannot convert artifact format: " + artifactoryFormattedPackageId +
            " because npm package ID cannot be parsed.");
        return Stream.empty();
      }
    }
    else {
      return Stream.of(nameOrNamespace);
    }
  }

  private boolean taskAppliesToRepository(final HostedRepository hostedRepository) {
    return proprietary.equals(hostedRepository.getMode());
  }
}
