/*
 * Copyright (c) 2019-present Sonatype, Inc. All rights reserved.
 * Includes the third-party code listed at http://links.sonatype.com/products/nexus/attributions.
 * "Sonatype" is a trademark of Sonatype, Inc.
 */
package com.sonatype.iq.artifactory

import com.sonatype.clm.dto.model.component.FirewallIgnorePatterns

import org.artifactory.repo.RepoPath

@Singleton(lazy = true)
class IgnorePatternMatcher
{
  private FirewallIgnorePatterns ignorePatterns

  private static final Map<String, Closure> FORMAT_HANDLERS = [
      'npm': { RepoPath repoPath -> repoPath.path }
  ].withDefault { { RepoPath repoPath -> repoPath.name } }

  boolean isIgnored(final String format, final RepoPath repoPath) {
    getPatterns(format)?.find {
      FORMAT_HANDLERS[format].call(repoPath) ==~ it
    }
  }

  void setIgnorePatterns(final FirewallIgnorePatterns ignorePatterns) {
    this.ignorePatterns = ignorePatterns
  }

  private getPatterns(final String format) {
    ignorePatterns?.regexpsByRepositoryFormat?.get(format)
  }
}
