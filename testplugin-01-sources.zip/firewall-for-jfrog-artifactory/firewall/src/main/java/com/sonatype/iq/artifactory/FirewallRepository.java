/*
 * Copyright (c) 2019-present Sonatype, Inc. All rights reserved.
 * Includes the third-party code listed at http://links.sonatype.com/products/nexus/attributions.
 * "Sonatype" is a trademark of Sonatype, Inc.
 */
package com.sonatype.iq.artifactory;

import com.sonatype.iq.artifactory.FirewallProperties.MODE;

import org.artifactory.repo.RepositoryConfiguration;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * Data class for a repository that is enabled for Firewall
 */
public class FirewallRepository
    extends AbstractRepository
{
  private static final Logger log = LoggerFactory.getLogger(FirewallRepository.class);

  private boolean audited;

  public FirewallRepository(
      final String repoKey,
      final MODE mode,
      final String type,
      final String format,
      final boolean audited)
  {
    super(repoKey, validateAndFixMode(mode, format), type, format);
    this.audited = audited;
  }

  public FirewallRepository(final String repoKey, final MODE mode, final String type, final String format) {
    this(repoKey, mode, type, format, false);
  }

  private static MODE validateAndFixMode(MODE mode, String format) {
    if (MODE.policyCompliantComponentSelection.equals(mode) && !"npm".equals(format)) {
      log.warn(MODE.policyCompliantComponentSelection.name() +
          " mode can be enabled only on npm repositories. Falling back to quarantine mode.");
      return MODE.quarantine;
    }

    return mode;
  }

  public static FirewallRepository of(RepositoryConfiguration repositoryConfiguration, MODE mode) {
    return new FirewallRepository(repositoryConfiguration.getKey(), mode, repositoryConfiguration.getType(),
        AbstractRepository.translateToIqFormat(repositoryConfiguration.getPackageType()));
  }

  public boolean getAudited() {
    return audited;
  }

  public void setAudited(final boolean audited) {
    this.audited = audited;
  }

  @Override
  public String getSupportedType() {
    return "remote";
  }

  @Override
  public boolean isHostedRepository() {
    return false;
  }

  public boolean isQuarantineEnabled() {
    return MODE.quarantine.equals(getMode()) || MODE.policyCompliantComponentSelection.equals(getMode());
  }

  public boolean isPolicyCompliantComponentSelectionEnabled() {
    return MODE.policyCompliantComponentSelection.equals(getMode());
  }
}
