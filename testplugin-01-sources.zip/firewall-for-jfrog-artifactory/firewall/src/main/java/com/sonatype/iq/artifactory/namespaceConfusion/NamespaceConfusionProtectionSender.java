/*
 * Copyright (c) 2019-present Sonatype, Inc. All rights reserved.
 * Includes the third-party code listed at http://links.sonatype.com/products/nexus/attributions.
 * "Sonatype" is a trademark of Sonatype, Inc.
 */
package com.sonatype.iq.artifactory.namespaceConfusion;

import java.util.ArrayList;
import java.util.Map;
import java.util.Objects;
import java.util.Set;
import java.util.concurrent.BlockingQueue;

import com.sonatype.iq.artifactory.IqConnectionManager;

import groovy.lang.Tuple2;

import static java.util.stream.Collectors.mapping;
import static java.util.stream.Collectors.partitioningBy;
import static java.util.stream.Collectors.toUnmodifiableSet;

public class NamespaceConfusionProtectionSender
{
  private final IqConnectionManager iqConnectionManager;

  private final static int BUFFER_SIZE = 100;

  public NamespaceConfusionProtectionSender(final IqConnectionManager iqConnectionManager) {
    this.iqConnectionManager = iqConnectionManager;
  }

  /**
   * Registers the given components on IQ server as proprietary component names.
   *
   * @param repoKey           repository key
   * @param format            repository format (using IQ, not artifactory format names)
   * @param nameAndNamespaces names and namespaces. The boolean field is set to true for names.
   */
  public void send(
      final String repoKey,
      final String format,
      final BlockingQueue<Tuple2<Boolean, String>> nameAndNamespaces)
  {
    ArrayList<Tuple2<Boolean, String>> buffer = new ArrayList<>(BUFFER_SIZE);

    while (!nameAndNamespaces.isEmpty()) {
      nameAndNamespaces.drainTo(buffer, BUFFER_SIZE);
      Map<Boolean, Set<String>> partitionedNamesAndNamespaces = buffer.stream()
          .filter(t -> !Objects.isNull(t.getSecond()))
          .collect(partitioningBy(Tuple2::getFirst, mapping(Tuple2::getSecond, toUnmodifiableSet())));

      Set<String> names = partitionedNamesAndNamespaces.get(true);
      Set<String> namespaces = partitionedNamesAndNamespaces.get(false);
      iqConnectionManager.addProprietaryComponentNames(repoKey, format, names, namespaces);
      buffer.clear();
    }
  }
}
