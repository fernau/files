/*
 * Copyright (c) 2019-present Sonatype, Inc. All rights reserved.
 * Includes the third-party code listed at http://links.sonatype.com/products/nexus/attributions.
 * "Sonatype" is a trademark of Sonatype, Inc.
 */
package com.sonatype.iq.artifactory;

import org.artifactory.repo.RepoPath;
import org.artifactory.repo.RepoPathFactory;

public class PathFactoryImpl
    implements PathFactory
{
  @Override
  public RepoPath createRepoPath(final String path) {
    return RepoPathFactory.create(path);
  }

  @Override
  public RepoPath createRepoPath(final String repoKey, final String path) {
    return RepoPathFactory.create(repoKey, path);
  }
}
