/*
 * Copyright (c) 2019-present Sonatype, Inc. All rights reserved.
 * Includes the third-party code listed at http://links.sonatype.com/products/nexus/attributions.
 * "Sonatype" is a trademark of Sonatype, Inc.
 */
package com.sonatype.iq.artifactory.audit

import java.time.Duration
import java.time.temporal.Temporal
import java.util.concurrent.Callable

import com.sonatype.iq.artifactory.FirewallArtifactoryAsset
import com.sonatype.iq.artifactory.FirewallRepository
import com.sonatype.iq.artifactory.IqConnectionManager
import com.sonatype.iq.artifactory.StorageManager

import groovy.transform.Canonical
import groovy.transform.ToString

import static com.google.common.base.Preconditions.checkNotNull
import static java.time.Duration.between
import static java.time.LocalDateTime.now

/**
 * Handles the specifics of requesting audit details from IQ and updating the local state of components once they're 
 * evaluated.
 */
class AuditTask
    implements Callable<AuditResult>
{
  final IqConnectionManager iqConnectionManager

  final StorageManager storageManager

  final FirewallRepository firewallRepository

  final Collection<FirewallArtifactoryAsset> assets

  AuditTask(final FirewallRepository firewallRepository, final Collection<FirewallArtifactoryAsset> assets,
            final StorageManager storageManager, final IqConnectionManager iqConnectionManager)
  {
    this.firewallRepository = checkNotNull(firewallRepository)
    this.assets = checkNotNull(assets)
    this.storageManager = checkNotNull(storageManager)
    this.iqConnectionManager = checkNotNull(iqConnectionManager)
  }

  @Override
  AuditResult call() throws Exception {
    Temporal start = now()
    iqConnectionManager.evaluateWithAudit(firewallRepository, assets)
    assets.each { FirewallArtifactoryAsset asset ->
      storageManager.assignAuditTimestamp(asset.getRepoPath())
    }
    return new AuditResult(repository: firewallRepository.repoKey, componentCount: assets.size(),
        duration: between(start, now()))
  }
}

@Canonical
@ToString(includeNames = true)
class AuditResult
{
  String repository

  long componentCount

  Duration duration
}
