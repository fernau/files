/*
 * Copyright (c) 2019-present Sonatype, Inc. All rights reserved.
 * Includes the third-party code listed at http://links.sonatype.com/products/nexus/attributions.
 * "Sonatype" is a trademark of Sonatype, Inc.
 */
package com.sonatype.iq.artifactory;

import java.util.Date;
import java.util.Set;
import java.util.concurrent.locks.Lock;

import com.google.common.util.concurrent.Striped;
import groovy.lang.Closure;
import groovy.lang.Reference;
import org.codehaus.groovy.runtime.DefaultGroovyMethods;
import org.slf4j.Logger;

public class UnquarantinedComponentsUpdater
{
  private final IqConnectionManager iqConnectionManager;

  private final StorageManager storageManager;

  private final QuarantineStatusManager quarantineStatusManager;

  private final PathFactory pathFactory;

  private final Logger log;

  private final long unquarantineUpdateMillis;

  private final Striped<Lock> striped = Striped.lock(32);

  public UnquarantinedComponentsUpdater(
      final IqConnectionManager iqConnectionManager,
      final StorageManager storageManager,
      final QuarantineStatusManager quarantineStatusManager,
      final PathFactory pathFactory,
      final FirewallProperties firewallProperties,
      final Logger log)
  {
    this.iqConnectionManager = iqConnectionManager;
    this.storageManager = storageManager;
    this.quarantineStatusManager = quarantineStatusManager;
    this.pathFactory = pathFactory;
    final Long millis = firewallProperties.getUnquarantineUpdateInMillis();
    this.unquarantineUpdateMillis = DefaultGroovyMethods.asBoolean(millis) ? millis : 60000;
    this.log = log;
  }

  public void requestAndUpdateUnquarantinedComponents(final FirewallRepository firewallRepository) {
    Lock lock = striped.get(firewallRepository.getRepoKey());

    if (!lock.tryLock()) {
      return;
    }

    try {
      final Reference<Date> lastUpdateTimestamp =
          new Reference<Date>(storageManager.getFirewallLastQuarantineUpdateTimestamp(firewallRepository.getRepoKey()));

      if (lastUpdateTimestamp.get() == null) {
        lastUpdateTimestamp.set(storageManager.getFirewallEnabledTimestamp(firewallRepository.getRepoKey()));
      }

      if (lastUpdateTimestamp.get() == null) {
        log.trace("Firewall skipped request for latest unquarantined assets: quarantine is not enabled");
        return;
      }

      final long timestamp = System.currentTimeMillis();
      if (timestamp - lastUpdateTimestamp.get().getTime() < unquarantineUpdateMillis) {
        log.trace("Firewall skipped request for latest unquarantined assets: " +
            String.valueOf(timestamp - lastUpdateTimestamp.get().getTime()) + "ms since last update");
        return;
      }

      log.info("Firewall is checking IQ server for unquarantined artifacts...");

      Set<String> pathnames;

      try {
        pathnames = iqConnectionManager
            .getUnquarantinedComponents(firewallRepository, lastUpdateTimestamp.get().getTime()).pathnames;
      }
      catch (UnsupportedOperationException e) {
        log.error("IQ Server doesn\'t support unquarantine request: " + e.getMessage());
        return;
      }

      DefaultGroovyMethods.each(pathnames, new Closure<Object>(this, this)
      {
        public void doCall(Object path) {
          getQuarantineStatusManager()
              .unQuarantine(getPathFactory().createRepoPath(firewallRepository.getRepoKey(), (String) path));
          getLog().info("Firewall unquarantined '{}' because it was unquarantined in IQ", path);
        }
      });

      storageManager.setQuarantineLastUpdateTimestamp(firewallRepository.getRepoKey(), timestamp);
      log.info("...Firewall unquarantined artifact check complete.  {} artifacts were unquarantined", pathnames.size());
    }
    finally {
      lock.unlock();
    }
  }

  public final IqConnectionManager getIqConnectionManager() {
    return iqConnectionManager;
  }

  public final StorageManager getStorageManager() {
    return storageManager;
  }

  public final QuarantineStatusManager getQuarantineStatusManager() {
    return quarantineStatusManager;
  }

  public final PathFactory getPathFactory() {
    return pathFactory;
  }

  public final Logger getLog() {
    return log;
  }

  public final long getUnquarantineUpdateMillis() {
    return unquarantineUpdateMillis;
  }

  public final Striped<Lock> getStriped() {
    return striped;
  }
}
