/*
 * Copyright (c) 2019-present Sonatype, Inc. All rights reserved.
 * Includes the third-party code listed at http://links.sonatype.com/products/nexus/attributions.
 * "Sonatype" is a trademark of Sonatype, Inc.
 */
package com.sonatype.iq.artifactory;

import java.util.Collection;
import java.util.HashMap;
import java.util.Map;

import static java.util.Collections.unmodifiableCollection;

public abstract class AbstractRepositories<T extends AbstractRepository>
{
  protected final Map<String, T> repos = new HashMap<>();

  /**
   * Adds new repository without overwriting existing entry
   *
   * @return false if the entry exists or true it a new entry was added
   */
  public abstract boolean add(final String repoKey, final T repository);

  public int count() {
    return repos.size();
  }

  public Collection<T> getRepositories() {
    return unmodifiableCollection(repos.values());
  }

  public T getRepository(final String key) {
    return repos.get(key);
  }
}
