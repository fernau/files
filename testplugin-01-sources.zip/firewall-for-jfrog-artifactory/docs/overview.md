<!--

    Copyright (c) 2019-present Sonatype, Inc. All rights reserved.
    Includes the third-party code listed at http://links.sonatype.com/products/nexus/attributions.
    "Sonatype" is a trademark of Sonatype, Inc.

-->
# Firewall for JFrog Artifactory Product Overview

The Firewall for JFrog Artifactory plugin extends jFrog Artifactory with the functionality provided by Nexus Firewall:

* Quarantine of components which fail policy evaluation
* Repository audit mode

The [documentation](https://help.sonatype.com/integrations/iq-server-and-repository-management/iq-server-and-firewall-for-artifactory)
contains information about installation and configuration of the plugin.

## High-Level Technical description

Blocking of quarantined components is implemented by hooking into the 'Download'
[(link)](https://www.jfrog.com/confluence/display/JFROG/User+Plugins#UserPlugins-Download) event of JFrog Artifactory. When
the policy evaluation of the requested component fails then a CancelException is thrown which will cause the Download
to be blocked. The plugin doesn't make use of a database or access the JFrog Artifactory database directly. However,
JFrog Artifactory 'properties' are used to store component metadata.

## Supported features

* Quarantine mode
* Audit mode
* Release components from quarantine
* Ignore patterns for audit paths
* Caching of policy evaluation result
* Safe mode
* Proprietary components

## Architecture Diagram

```
  .-----------. (2)    (3) .-------------------. (1)   (4) .--------.
  | IQ Server | <--------> | JFrog Artifactory | <-------> | Client |
  `-----------`    REST    `-------------------`   HTTP    `--------`
```

1) Request for a component received by JFrog Artifactory
2) Component evaluated on IQ Server
3) ALLOW / DENY status received and saved to cache
4) Access to component is allowed or denied

## How the Firewall for JFrog Artifactory works

Artifactory's plugins allow extending Artifactory's behaviour to perform [tasks](https://www.jfrog.com/confluence/display/JFROG/User+Plugins#UserPlugins-AboutPlugins) 
as handling and manipulating download events, perform searches, query artifacts and metadata, etc. The plugins need to be
written in Groovy but is possible having an entrypoint file in Groovy and from there call Java classes. In this plugin the 
entrypoint is the [nexusFirewallForArtifactoryPlugin.groovy](https://github.com/sonatype/firewall-for-jfrog-artifactory/blob/main/plugin/src/main/java/com/sonatype/iq/artifactory/nexusFirewallForArtifactoryPlugin.groovy)
file and follows the [plugin template source](https://www.jfrog.com/confluence/display/JFROG/User+Plugins#UserPlugins-PluginTemplateSource).

The plugin is designed to handle external executions and handle download and storage events. The following executions and event handlers are defined in the plugin:

- **Executions**
  - firewallEvaluationSummary: Returns a summary for the Firewall policy evaluation for a particular repository.
  - firewallVersion: Returns the plugin version.
- **Download handler event types**
  - beforeDownload: Makes a call to Firewall to process the component and determine if it is possible to download the component.
  - altRemoteContent: Makes a call to Firewall and removes quarantinable versions from NPM component metadata.
- **Storage handler event types**
  - beforePropertyCreate: Checks property access.
  - beforePropertyDelete: Checks property access.
  - afterDelete: Calls Firewall to remove component from internal database.

An example of the workflow of the plugin is the next:

![Sequence Diagram - Download od components](sequence_diagram.png "Sequence diagram - download components") 

## How to set up the plugin

Running the Maven package phase (`mvn package`) generates an artifact in the target folder. This artifact is created with the name
`nexus-iq-artifactory-plugin-$PLUGIN_VERSION-.zip`. When you unzip this file you encounter the following structure:

- firewall.properties.example: All the properties related to the firewall connection and repository configuration.
- nexusFirewallForArtifactoryPlugin.groovy: the plugin itself. This is the file called by Artifactory.
- lib/nexus-iq-artifactory-plugin.jar: All the code called by the plugin.

To install the plugin you need to extract the zip file into JFrog Artifactory's `/plugins` directory. The location of this folder
could change depending on which Artifactory version you are using. [For more details see](https://help.sonatype.com/fw/getting-started/jfrog-artifactory-setup).

When you have the files extracted into the `/plugins` directory, the `firewall.properties.example` file needs to be renamed to `firewall.properties` and
configured to point to the IQ server. [See configuration example](https://help.sonatype.com/fw/getting-started/jfrog-artifactory-setup#JFrogArtifactorySetup-configurationConfiguration).

The Artifactory server needs to be restarted after the plugin is installed and configured. This could vary depending on the installation method.
In Unix systems configured to run Artifactory as a service we will only need to run the following command:

`systemctl restart artifactory.service`

## About JFrog Artifactory plugins

To keep this plugin as stable as possible across JFrog Artifactory releases we only use functionality provided by the
official [plugin APIs](https://www.jfrog.com/confluence/display/JFROG/User+Plugins).

## Project directory layout

* **assembly**: Builds artifact using maven-assembly-plugin
* **docs**: This directory. Contains the technical information related to the plugin.
* **firewall**: Builds the firewall-plugin's jar file. All code related to the communication with Nexus IQ.
* **plugin**: Contains the groovy file implementing the plugin. It follows the [plugin template](https://www.jfrog.com/confluence/display/JFROG/User+Plugins#UserPlugins-PluginTemplateSource).

## Build instructions

For building this plugin is required to have installed the following tools:

- Maven 3.6.x or higher
- Java - JDK 11

To build and package the plugin, use the package maven goal:

`mvn package`

**Note**: It's also required to have the  **Artifactory Public API** [jar](https://javadoc.io/doc/org.artifactory/artifactory-papi/latest/index.html) to build the project.
You need to add it to your local cache or repository server. This can be achieved using the following command specifying the route to the jar:

`mvn install:install-file -Dfile=/tmp/artifactory-papi-7.12.5.jar -DgroupId=org.artifactory -DartifactId=artifactory-papi -Dversion=7.12.5 -Dpackaging=jar`

## Unit testing

All new unit tests should be placed in the [test folder](https://github.com/sonatype/firewall-for-jfrog-artifactory/tree/main/firewall/src/test) of the `firewall` module. 
The tests are written in Groovy and use [Spock framework](https://spockframework.org/) to create test specifications and are organized following the same package
structure as the source code from the [src directory](https://github.com/sonatype/firewall-for-jfrog-artifactory/tree/main/firewall/src/main/java/com/sonatype/iq/artifactory).

## How to run the tests

Running tests is possible in different ways using the maven goal from the command-line or using an IDE that uses the maven goal underneath.
Using the command line is as simple as running `mvn test` command in the `firewall` module. For running the tests from an IDE please refer to the documentation of you favorite IDE

- [IntelliJ IDEA](https://www.jetbrains.com/help/idea/performing-tests.html#run-tests-before-commit)
- [Netbeans](https://netbeans.apache.org/tutorials/nbm-test.html)
- [Eclipse](https://wiki.eclipse.org/Eclipse/Testing)

## How to debug

To debug the plugin is possible to do it in two different ways:

- Remote debug the plugin installed in the Artifactory Server Pro
- Set up your favorite IDE (see prior section) to run tests and set breakpoints to stop the execution and step through the code.

## Relevant information for new features

### Jobs are only executed on one node

Job defined in the plugin are only executed on ONE node. If you depend on some functionality to be executed on every node you cannot rely on an artifactory jobs definition.

### Threads have limited access to Artifact properties

Threads have limited access to Artifact properties.

- Writing to properties from threads appears to work. However, due to the lack of documentation about this we should not rely on it.
- Reading attributes from threads other than an event thread always returns null. It is not possible to distinguish an empty value from a failed read. NEVER read attributes from non-event handling threads (jobs, download handlers, etc. are fine)

## Use user and system permissions correctly

Using Artifact properties from System threads (e.g. the init-thread) does not work reliably. However, when using event threads instead make sure the 'asSystem' closure is used if needed. For example AQL queries cannot be performed as anonymous user. 
Do not use the 'asSystem' closure for downloading the Artifacts because this would allow users to bypass permission checks.
